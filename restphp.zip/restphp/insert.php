<?php 
// $conn=mysql_connect("localhost","root","");
// mysql_select_db('api');
   // if(! $conn ) {
      // die('Could not connect: ' . mysql_error());
   // }
   // $sql="insert into user(name, age, address) values('c', 5, 'ghi')";
	// $query=mysql_query($sql,$conn);
	// $query=json_encode($query);
	
 ?>
 
 
 <?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
$data = json_decode( file_get_contents('php://input'),true );
echo $data;
  $sal =  $data['salary'];
  $rent =  $data['rent'];
  $emi =  $data['emi'];
  $travel =  $data['travel'];
  $pi =  $data['pi'];
$conn=mysql_connect("localhost","root","");
mysql_select_db('api');
if(! $conn ) {
      die('Could not connect: ' . mysql_error());
    }
if($sal!='' || $rent!='' || $emi!='' || $travel!='' || $pi!=''){
$sql = "insert into exdata(salary,rent,emi,travel,pi)values('".$sal."','".$rent."','".$emi."','".$travel."','".$pi."')";
//echo $sql;
$query=mysql_query($sql,$conn);;
//echo "Inserted";
echo $query;
}
else{
echo "nothing";
}
?>