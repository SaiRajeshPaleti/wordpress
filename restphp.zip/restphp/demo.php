<?php 
header("Access-Control-Allow-Origin: *");
$conn=mysql_connect("localhost","root","");
mysql_select_db('api');
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   $sql="select * from exdata";
	$query=mysql_query($sql,$conn);
	
	while($row = mysql_fetch_assoc($query)){
	$data[]=$row;
	}
	echo json_encode($data);
?>