<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package salessite2
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<!-- Basic Page Needs  ================================================== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!-- Mobile Specific Metas & Title ============================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=0">
    <title>Sales Site</title>
    <!-- Library CSS  ================================================== -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo get_template_directory_uri(); ?>/css/bootstrap/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo get_template_directory_uri(); ?>/css/kendo/kendo.common-material.min.css" rel="stylesheet" />
    <link href="<?php echo get_template_directory_uri(); ?>/css/kendo/kendo.material.min.css" rel="stylesheet" />

    <!-- Link Swiper CSS  ================================================== -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/swiper/swiper.min.css">
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/cdn-swiper.js"></script>
    <!--    <script src="/scripts/swiper.js"></script>-->
    <!--   <script src="/scripts/swiper.min.js"></script>-->
    <!-- CSS  ================================================== -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/custom.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/responsive.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/kendo.css" />
    <!-- jQuery Lib & Custom Java Scripts  ================================================== -->
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/jquery.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/jquery.slimscroll.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/kendo.all.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/floatingicons.js"></script>
    <!--<script src="/scripts/custom.js"></script>-->
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/customkendo.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/scripts/data.js"></script>

	<?php //wp_head(); ?>
</head>

<body>
<header class="header-wrapper">
        <div class="container-custom">
            <div class="header-container">
                <nav class="navigation-menu navbar navbar-inverse">
                    <button type="button" class="navbar-toggle collapse collapsed" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar top-bar"></span>
                        <span class="icon-bar middle-bar"></span>
                        <span class="icon-bar bottom-bar"></span>
                    </button>
                    <div class="logo">
                        <a href="/html/index.html">
                        <img class="img-logo" src="<?php echo get_template_directory_uri(); ?>/images/ae_logo.svg" alt="AE-exchange-logo">
                            </a>
                    </div>
                    <div class="primary-nav">
                        <ul class="nav navbar-nav topmenu">

                            <li> <?php //require get_template_directory()."/dist/index.html";?> </li>

                        </ul>
                    </div>
                    <!--  <div class="clearfix"></div>-->
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <div class="navigation-container">
                            <div class="float-right auto-search-tablet" style="display:none">

                                <div class="position-relative search-wrapper">
                                    <span><i class="fa fa-search search-auto" aria-hidden="true"></i></span>
                                    <input class="auto-search" type="text" placeholder="Enter Search" id="autocomplete-tablet" />
                                    <span><a class="search-text" href="#">SEARCH</a></span>
                                    <span class="search-cancel"><i class="fa fa-times" aria-hidden="true"></i></span>
                                </div>
                            </div>

                            <ul class="nav navbar-nav menu-wrapper-tab hidden-lg hidden-md">

                                <li><a href="/html/index.html"><span class="pipe">|</span>scripted</a></li>

                                <li><a href="/html/factual.html"><span class="pipe">|</span>Factual</a></li>

                                <li><a href="#"><span class="pipe">|</span>Movies</a></li>

                                <li><a href="#"><span class="pipe">|</span>Formats</a></li>

                            </ul>
                            <div class="secondary-nav">
                                <ul class="nav navbar-nav navbar-right menu-wrapper-tab">
                                    <li><a class="text-grey account-history" href="#"> My Watch List</a></li>
                                    <li><a class="text-grey account-history" href="#">Contacts</a></li>
                                    <li><a class="text-grey account-history hidden-sm" data-toggle="modal" href="#myModal" data-modal-fit-viewport="true">Sign In</a></li>
                                    <li><a class="text-grey account-history hidden-lg hidden-md" data-toggle="modal" href="#myModal2" data-modal-fit-viewport="true">Sign In</a></li>

                                    <li class="hidden-tablet hidden-sm"><a class="text-grey account-history"><span class="search-icon"><i class="fa fa-search" aria-hidden="true"></i></span></a></li>
                                </ul>
                            </div>
                            <!--modal-body-tablet -->

                            <div class="modal-body-tablet hidden-lg hidden-md">
                                <form>
                                    <div class="form-group">
                                        <label for="usrname" class="signup-label">Username</label>
                                        <input type="text" class="form-control text-capitalize" id="usrname" placeholder="Enter email" value="JohnDoe123">
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="form-group">
                                        <label for="psw" class="signup-label">Password</label>
                                        <input type="text" class="form-control" id="psw" placeholder="Enter password">
                                        <div class="clearfix"></div>
                                    </div>
                                    <!--<div class="checkbox">
              <label><input type="checkbox" value="" checked>Remember me</label>
            </div>-->

                                    <button type="submit" class="btn btn-md signin-btn bg-gold">Update Password</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>

                            <!--modal-body-tablet ends -->
                            <div class="float-right auto-search" style="display:none">

                                <div class="position-relative search-wrapper">
                                    <span><i class="fa fa-search search-auto" aria-hidden="true"></i></span>
                                    <input class="auto-search" type="text" placeholder="Enter Search" id="autocomplete" />
                                    <span><a class="search-text" href="#">SEARCH</a></span>
                                    <span class="search-cancel"><i class="fa fa-times" aria-hidden="true"></i></span>
                                </div>
                            </div>

                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <div class="visible-lg visible-md container-custom position-relative">
            <input id="active-watchlist-dd" class="custom-active-watchlist" style="width:21%" />
        </div>

    </header>
    <div class="body-container">