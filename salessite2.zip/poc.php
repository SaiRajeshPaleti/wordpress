<?php
/*
Template Name: poc
*/
?>

<?php
the_field('html');
 ?>