$(document).ready(function () {
$("#active-watchlist-dd").kendoDropDownList({
		dataTextField: "title",
        dataValueField: "title",
		dataSource: wl_active,
		valueTemplate:'<div class="wl-active visible-lg-inline-block"><span class="float-right clearfix">Active</span><span class="float-right clearfix">Watchlist</span></div><div class="pipe visible-lg-inline-block">|</div><a class="watchlist-value" href="javascript:void(0)"><span class="wl-value-ellipsis">#: data.title #</span><span class="">(#: data.list #)</span></a>',
		template:'<a href="javascript:void(0)" class="wl-text"><span class="visible-lg-inline-block wl-ellipsis">#: data.title #</span><span class="visible-lg-inline-block float-right">(#: data.list #)</span></a>'
	});
});
