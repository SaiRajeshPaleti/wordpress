var swiper = new Swiper('.swiper-container', {
      pagination: '.swiper-pagination',
      nextButton: '.swiper-button-next',
      prevButton: '.swiper-button-prev',
      paginationType: 'custom',
      preventClicks:'true',
      setWrapperSize:'true',
//       allowSwipeToNext:'true',
//      allowSwipeToPrev:'true',
//      longSwipesRatio:"5",
     // slideToClickedSlide:true,
      //onSlideClick: moveToClickedNumber,
      initialSlide: 0,
//      CSSWidthAndHeight: true,
    /*   observer:true,*/
      grabCursor: false,
      keyboardControl: true,
//      paginationClickable: true,
     /* lastSlideMessage:'This is the last slide'*/
     /* centeredSlides: true,*/
      breakpoints: {
          // when window width is <= 320px
          362: {
              slidesPerView: 1,
              spaceBetween: 30,
              paginationCustomRender: function (swiper, current, total) {
                  return '0' + current + '/' + '0' + swiper.slides.length;

              },
          },
          // when window width is <= 480px
          770: {
              slidesPerView: 2,
              spaceBetween: 35,
              paginationCustomRender: function (swiper, current, total) {
                  return '0' + current + '-' + '0' + (current + 1) + '/' + '0' + swiper.slides.length;

              },
          },
          // when window width is <= 640px

          1600: {
              slidesPerView: 4,
              spaceBetween: 10,
              onInit(swiper) {
                   $(' .swiper-slide-next').next().next().css("opacity","0.3");
                   $(' .swiper-slide-next').next().next().addClass("default-slide");
                     $(' .default-slide').css("opacity","0.3");
              },
                    onSlideNextStart: function (swiper) {
                       var slides = $('.swiper-container .swiper-slide').length; 
               /*         var lastslide = slides-1; 
                        swiper.slideTo(lastslide);   */
     /*   $('.swiper-pagination-switch').removeClass('swiper-slide-active');
        $('.swiper-pagination-switch').eq(swiper.activeSlide).addClass('swiper-slide-active');
        
               */         /*var activeIndex = swiper.activeIndex;
                        var realIndex = swiper.slides.eq(activeIndex).attr('data-swiper-slide-index'); 
                        $('.swiper-slide').removeClass('my-active');
                        $('.swiper-slide[data-swiper-slide-index="'+realIndex+'"]').addClass('my-active'); */
                        
                        $('.swiper-slide-next,.swiper-slide-active').css("opacity", "1");
                       /* setTimeout(function() {*/
							$('.swiper-slide-active').addClass("test-prev");
                          /*  if ($(".swiper-slide:eq(0)").hasClass("swiper-slide-active")) {
                            $('.swiper-slide-active').addClass("test-prev");
                            }
                            else {
                            $(".swiper-slide-active").removeClass("test-prev"); 
                            }*/
                          $('.swiper-slide-next').next().next().next().addClass("test-next");
                            $('.swiper-slide-next').next().next().removeClass("test-next");
                              $(' .swiper-slide-next').next().css("opacity","1");
                         $(' .swiper-slide-next').next().next().css("opacity","1");
                            /*  $(' .default-slide').css("opacity","1");*/
                          /*  $(' .swiper-slide-next').next().next().css("opacity","0.3");*/

                   /* },200);*/
                },
              
               onSlidePrevStart: function (swiper) {
							$('.swiper-slide-prev').removeClass("test1");
                      $('.swiper-slide-next').next().next().next().addClass("test-next");
                  /*   $(' .default-slide').prev().css("opacity","0.3");*/
							$('.swiper-slide-next').removeClass("test-prev");
                   $('.swiper-slide-next').next().removeClass("test-prev"); 
                            /*$(' .default-slide').css("opacity","0.3");*/
                },
              
              
          },
		  
		  2400: {
              slidesPerView: 4,
              spaceBetween: 25,
          },
		  
		  6400: {
              slidesPerView: 4,
              spaceBetween: 25,
          }
      }
  });

/*$(window).resize(function(){
  $('.swiper-container').css({
    width:1600px;
    height: 300px;
  })
  swiper.reInit() // or swiper.resizeFix()
})*/

  /*if ($(".swiper-slide:eq(0)").hasClass("swiper-slide-active")) {
    $(".suggestions-img").css("opacity","0.2");
  }
  else {
    $(".suggestions-img").css("opacity","1");
  }*/

//$(document).ready(function(){
//   $(".ia-container input").on("mouseenter",function(){
//       $('.ia-container input:hover ~ figure').css("left", "5%");
//      $('.ia-container input:not(:hover) ~ figure').css("left", "1.875%");
//    /*   $('.ia-container input:hover + figcaption .box h1').css("padding", "15px");*/
//      /*  $('.ia-container input:not(:hover) + figcaption .box h1').css("font-size","10px");*/
//       $('.ia-container input:not(:hover) + figcaption .box h1').css("padding", "0px");
//      /* $('.ia-container input:not(:hover) + figcaption .box h1').css("font-size", "8px");*/
//      $('.ia-container input:not(:hover) + figcaption .box h1').css(" line-height", "0px");
//    }).on("mouseleave",function(){
//       $('.ia-container input ~ figure').css("left", "2.5%");
//    });
//	
//	$('input').click(function () {
//       $('.ia-container input:not(:hover) ~ figure').css("left", "2.5%");
//  });
//});


//$(document).ready(function(){  
//  $('.ia-container input').hover(
//      
//      function() {
//   
//      $('.ia-container input:hover ~ figure').css("left", "5%");
//      $('.ia-container input:not(:hover) ~ figure').css("left", "1.875%");
//    /*   $('.ia-container input:hover + figcaption .box h1').css("padding", "15px");*/
//      /*  $('.ia-container input:not(:hover) + figcaption .box h1').css("font-size","10px");*/
//       $('.ia-container input:not(:hover) + figcaption .box h1').css("padding", "0px");
//      /* $('.ia-container input:not(:hover) + figcaption .box h1').css("font-size", "8px");*/
//      $('.ia-container input:not(:hover) + figcaption .box h1').css(" line-height", "0px");
//       
//  
//  },
//           function() {
//     
//      $('.ia-container input ~ figure').css("left", "2.5%");
//  });
//
//$('input').click(function () {
//       $('.ia-container input:not(:hover) ~ figure').css("left", "2.5%");
//  });
//});
//   $(".swiper-wrapper").allowSwipeToNext(function() {  
  /*     $('.swiper-slide-active').addClass('custom-slide-prev');*/
      // $('.swiper-slide-active').removeClass('swiper-slide-active');
//            });  

/*$('.swiper-slide-active').addClass('swiper-slide-prev');*/
/*$('.swiper-slide-active').removeClass('.swiper-slide-prev');*/

$(".swiper-button-next").click(function() {
     $('.content-wrapper').css("padding-left", "0");
     //  $('.swiper-images').css("padding-right", "60px");
  
   
 });

if ($(".swiper-slide:eq(0)").hasClass("swiper-slide-active")) {
$(".arrow-left").css("opacity","0.2");
}
else {
$(".arrow-left").css("opacity","1");
}   


var data = [
    "A who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn","Who KIlled mandjkdn",
];

  $("#autocomplete").kendoAutoComplete({
	  minlegth:1,
      autoWidth: true,
      dataSource: data,
		filter: "startswith",
		separator: ", ",
	  template: $.proxy(kendo.template("#= formatValue(data, this.val()) #"), $("#autocomplete"))
	
  });
 $("#autocomplete-tablet").kendoAutoComplete({
	  minlegth:1,
      autoWidth: true,
      dataSource: data,
		filter: "startswith",
		separator: ", ",
	  template: $.proxy(kendo.template("#= formatValue(data, this.val()) #"), $("#autocomplete-tablet"))
	
  });

	function formatValue(itemText, text) {
          var textMatcher = new RegExp(text, "ig");

          return itemText.replace(textMatcher, function(match) {
            return "<span class='text-gold'>" + match + "</span>";
          });
        }


	$(".fa-search").click(function() {
     $('.navbar-right').css("display", "none");
	$('.auto-search').css("display", "inline-block");
    
 });
	$(".search-cancel").click(function() {
     $('.navbar-right').css("display", "inline-block");
	$('.auto-search').css("display", "none");
    
 });


 $(".swiper-button-next.swiper-button-disabled").click(function() {
     $('.swiper-slide-prev').css("margin-left", "-150px");
 });














 /*var vert-swiper = new Swiper('.vertical-swiper-container', {
        direction: 'vertical',
      centeredSlides: true,
      longSwipesRatio :500,
      breakpoints: {
          // when window width is <= 320px
          362: {
              slidesPerView: 1,
              spaceBetween: 25,
              paginationCustomRender: function (swiper, current, total) {
                  return '0' + current + '/' + '0' + swiper.slides.length;

              },
          },
          // when window width is <= 480px
          770: {
              slidesPerView: 2,
              spaceBetween: 35,
              paginationCustomRender: function (swiper, current, total) {
                  return '0' + current + '-' + '0' + (current + 1) + '/' + '0' + swiper.slides.length;

              },
          },
          // when window width is <= 640px

          1600: {
              slidesPerView: 4,
              spaceBetween: 0,
          },
		  
		  2400: {
              slidesPerView: 4,
              spaceBetween: 25,
          },
		  
		  6400: {
              slidesPerView: 4,
              spaceBetween: 25,
          }
      }
  });*/