var wl_active=[
	{
		title:"WATCH LIST NAME LOREM",
		list:"5",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET CONSECTETER",
		list:"25",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET",
		list:"35",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET CONSECTETER",
		list:"25",
	},
    {
		title:"WATCH LIST NAME LOREM",
		list:"5",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET CONSECTETER",
		list:"15",
	}
    
];