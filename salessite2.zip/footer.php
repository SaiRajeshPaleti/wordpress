<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package salessite2
 */

?>

	</div><!-- #content -->

	<footer>
            <div class="container-custom">
                <div class="copy-right clearfix">
                    <div class="account-details float-left">
                        <div class="pwd float-left"><span class="icon-user"><i class="fa fa-user" aria-hidden="true"></i></span>Change password</div>

                        <div class="email float-right">Contact:<span class="mail-id">INTL.SALES@AENETWORKS.COM</span></div>
                    </div>

                    <ul class="terms-policy float-right">
                        <li><a href="#">press</a></li>
                        <li><a href="#">faq</a></li>
                        <li><a href="#">terms of service</a></li>
                        <li><a href="#">privacy policy</a></li>
                    </ul>
                </div>
            </div>
        </footer>
        <!-- Modal -->
        <div class="modal fade container-custom" id="myModal" role="dialog">
            <div class="modal-dialog modal-sm">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h1>Sign in</h1>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div class="form-group">
                                <label for="usrname" class="pull-left signup-label">Username</label>
                                <input type="text" class="form-control pull-right text-capitalize" id="usrname" placeholder="Enter email" value="janeSmith">
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-group">
                                <label for="psw" class="pull-left signup-label">Password</label>
                                <input type="text" class="form-control pull-right" id="psw" placeholder="Enter password">
                                <div class="clearfix"></div>
                            </div>
                            <!--<div class="checkbox">
              <label><input type="checkbox" value="" checked>Remember me</label>
            </div>-->

                            <button type="submit" class="btn btn-md pull-right signin-btn bg-gold">Sign In</button>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <ul class="reset-pwd signin pull-left ">
                            <li class="text-center"><a href="#">Forgot your password?</a></li>
                            <li class="text-uppercase"><a class="text-gold" href="#">Reset your password</a></li>
                        </ul>
                        <span class="seprtor text-center">|</span>
                        <ul class="acc-regstr signin pull-right">
                            <li class="text-center"><a href="#">Dont have an account?</a></li>
                            <li class="text-uppercase"><a class="text-gold" href="#">Register@aenetworks.com</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
        <!--modal ends-->

    </div>

    <script src="<?php echo get_template_directory_uri(); ?>/scripts/script.js"></script>
    <script>
        $(document).ready(function() {

            $(".ia-container input").on("mouseenter", function() {
                    $('.ia-container input:hover ~ figure').css("left", "5.877%");
                    $('.ia-container input:not(:hover) ~ figure').css("left", "1.5%");
                    //  $('.ia-container input:hover + figcaption .box .screener-title').addClass("test");
                    $('.ia-container figcaption .box .screener-title').css("left", "2px");
                    $('.ia-container input:not(:hover) figcaption .box .screener-title').css("padding", "0 8px");
                    $('.ia-container input:not(:hover) + figcaption .box .screener-title').css("padding", "0 0px");
                    $('.ia-container input:hover + figcaption .box .screener-title').css("padding", "0 30px");
                    /* $('.ia-container input:not(:hover) + figcaption .box h1').css("font-size", "8px");*/
                    $('.ia-container input:not(:hover) + figcaption .box .screener-title').css(" line-height", "0px");
                    // $('.ia-container input:not(:hover) + figcaption .box .screener-title').css("padding", "0");
                })
                .on("mouseleave", function() {
                    $('.ia-container input ~ figure').css("left", "2.5%");
                    $('.ia-container figcaption .box .screener-title').css("left", "2px");
                    $('.ia-container input:not(:hover) figcaption .box .screener-title').css("padding", "0 30px");
                    $('.ia-container input:not(:hover) ~ figcaption .box .screener-title').css("padding", "0 8px");
                    $('.ia-container input:checked ~ figcaption .box .screener-title').css("padding", "0 0");

                    //$('.ia-container input:not(:hover) + figcaption .box .screener-title').css("padding", "0 0px");
                    // $('.ia-container input:hover + figcaption .box .screener-title').removeClass("test");
                });



            $('input').click(function() {
                $('.ia-container input:not(:hover) ~ figure').css("left", "2.5%");
            });

            /*slim scroll*/
            $(function() {
                $('#autocomplete_listbox').slimScroll({
                    size: '5px',
                    height: '100%',
                    color: 'rgb(187, 187, 187)',
                    alwaysVisible: true,
                });
            });
            $(function() {
                $('.navigation-container').slimScroll({
                    size: '5px',
                    height: '100%',
                    color: 'rgb(187, 187, 187)',
                    alwaysVisible: true,
                });
            });

            $(window).scroll(function() {

                if ($(window).scrollTop() > 80) {
                    $('.header-wrapper').addClass('fixed-header');
                } else {
                    $('.header-wrapper').removeClass('fixed-header');
                }
            });

        });

    </script>
</body>
</html>
