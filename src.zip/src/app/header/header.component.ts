import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  private dataURL= 'http://localhost:8012/WPS/wp-json/wp/v2/menu';

  constructor(private _http: Http) { }

  ngOnInit() {
  }


  a:String = '';

  getdata() : Observable<String []> {

return this._http.get(this.dataURL).map(res :Response => <String []>res.json()) 

  }


}
