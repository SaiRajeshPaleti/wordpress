export class Exdata {
    salary:number=18000;
  rent:number=0;
  emi:number=0;
  travel:number=0;
  pi:number=0;

}