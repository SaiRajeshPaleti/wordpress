import { Component } from '@angular/core';
import {Exdata} from './model';
import {DatatransferService} from './datatransfer.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 title = 'app';
  ex=new Exdata;
  getResponse:any;

  constructor(private dts :DatatransferService){
  }
   ngOnInit(){
    
  }
  



  salaryrent(value:number):number{
    this.ex.salary=this.ex.salary-value;
    
    return this.ex.salary;
  }
savedata(){
 
 if(this.dts.insertdata(this.ex)) 
 alert("success");
}

viewdata(){
  this.dts.getdata().subscribe((res) => this.getResponse = res);
}
}
