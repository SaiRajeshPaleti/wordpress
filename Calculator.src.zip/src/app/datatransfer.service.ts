import { Injectable } from '@angular/core';
import {Exdata} from './model';
import {Observable} from 'rxjs/observable';
import {Http,Response,RequestOptions,Headers} from '@angular/http';
//import { Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map'; 


@Injectable()
export class DatatransferService {
  ex=new Exdata;
  postResponse:any ;
  constructor(private http:Http) { }

insertdata(ex){
  let headers = new Headers({ 'Content-Type': 'application/json' });
  let options = new RequestOptions({ headers: headers });
  return this.http.post('http://localhost:8012/restphp/insert.php',JSON.stringify(ex),{headers:headers})
    .map((res: Response) => res.json())
    .subscribe((res:'') => this.postResponse = res);
}

getdata(){
  return this.http.get('http://localhost:8012/restphp/demo.php')
  .map((res:Response)=>{ return res.json(); });
}

}








