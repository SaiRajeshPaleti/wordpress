//function to hightlight searched value
function formatValue(itemText, text) {
	var textMatcher = new RegExp(text, "ig");

	return itemText.replace(textMatcher, function (match) {
		return "<span class='text-gold'>" + match + "</span>";
	});
}

$(document).ready(function () {
	/*======Error page Height====*/
	/*===mAtching height for bootstrap columns===*/
	 $('.thumbnail-block').matchHeight();
	 $('.contact-block').matchHeight();
	 $('.press-block').matchHeight();
	/*===mAtching height for bootstrap columns Ends===*/
	/*====Calculating content height of overview section=====*/
	var overViewHeight = $('.scripted-detail-title-section').outerHeight();
	$('.overview-block,.scripted-details-title-image').css("height",overViewHeight);
	/*====Calculating content height of crew section=====*/
	var crewContentHeight = $('.details-crew-container').outerHeight();
	$('.crew-block-bw,.scripted-details-crew-image').css("height",crewContentHeight);

	$(".ae-button-watch-trailer").click(function () { 
	$(".ae-button-watch-trailer .watch-series-trailer").toggleClass("clicked");
	if ($(".watch-series-trailer").hasClass('clicked')) {
		var currentBgHeight = $(".scripted-details-title-image").outerHeight(true);
		var hiddenContainerHeight = $(".watch-series-trailer-container").outerHeight(true);
		var totalHeight=currentBgHeight+hiddenContainerHeight;
		$(".overview-block,.scripted-details-title-image").css("height",totalHeight);
		$(".watch-series-trailer-container").show();
		
	}
	else {                        
		$(".watch-series-trailer-container").hide();
		var currentBgHeight = $(".scripted-details-title-image").outerHeight(true);
		var hiddenContainerHeight = $(".watch-series-trailer-container").outerHeight(true);
		var totalHeight=currentBgHeight-hiddenContainerHeight;
		$(".overview-block,.scripted-details-title-image").css("height",totalHeight);
		
	}
});
	 $( window ).resize(function() {
		/*====Calculating content height of overview section=====*/
	var overViewHeight = $('.scripted-detail-title-section').outerHeight();
	$('.overview-block,.scripted-details-title-image').css("height",overViewHeight);
	/*====Calculating content height of crew section=====*/
	var crewContentHeight = $('.details-crew-container').outerHeight();
	$('.crew-block-bw,.scripted-details-crew-image').css("height",crewContentHeight);
	 });
	$(document).on('click', '.navbar-toggle', function () {	
		if($('.navbar-toggle').hasClass('active')){
			$(".navbar-collapse").removeClass("in");    
			$('.navbar-toggle').removeClass("active");
			$('.overlay-toggle-body').hide();
		}
		else{
			$(".navbar-collapse").addClass("in");    
			$('.navbar-toggle').addClass("active");
			$('.overlay-toggle-body').show();
		}
		
	});		
	$(document).on('click', '.overlay-toggle-body', function () {
		$(".navbar-collapse").removeClass("in");    
		$('.navbar-toggle').removeClass("active");
		$('.overlay-toggle-body').hide();
	});	
	/*===navbar menu close on click of details-nav====*/ 
	$('.details-nav li').on('click', function() {
        $(".navbar-toggle").removeClass("active");
		$(".navbar-collapse").removeClass("in");
		$('body').removeClass('menu-open');
		$('.overlay-toggle-body').hide();
	})
	/*====Details sticky header scroll to====*/
	$(".details-nav a").on('click',function(event){ 
		event.preventDefault();
		var o =  $( $(this).attr("href") ).offset();   
		var sT = o.top - $(".navbar--custom").outerHeight(true); 
		window.scrollTo(0,sT);
	}); 
	//Microsite protected video validation
	$(".on-click-login").click(function(){
		$(this).removeClass("play-btn");
		$(".password-protected-container").show();
		$(".password-protected-xs").show();
	});
	 
	$('#video-signin').click(function () {
		var videoPasswordVal = $('#video-password').val();
		if (videoPasswordVal === "1234") {
			$('#protected-video').show();
			$('#micro-vid-link').hide();
		}
		else{
			$('#video-password').addClass('validation-error');
		}
	});
	/*===swiper==*/
	$(".add-to-watchlist").click(function () {
		if($(this).attr('class') == "add-to-watchlist"){      
			$(this).addClass("added-to-watchlist");
		}
	else{
		 $(this).addClass("add-to-watchlist");
		 $(this).removeClass("added-to-watchlist");
	   }
	
	});
	/*===swiper ends*/
	$(".navbar__navlink.text-gold-selected").click(function () {
		$(this).addClass("text-gold");
		// $(this).css("color","#c6ae65");
	});

	/*==navbar search==*/
	$(".nav-search").click(function () {
		$('.navbar-right').css("display", "none");
		$('.auto-search').css("display", "inline-block");

	});
	$(".search-cancel").click(function () {
		$('.navbar-right').css("display", "inline-block");
		$('.auto-search').css("display", "none");

	});
	/*navbar search ends*/
	/*===Hamburger Icon===*/
	// $(".navbar-toggle").on("click", function () {
	// 	$(this).toggleClass("active");
	// });
	/*===Hamburger Icon Ends===*/
	/*====Update Passowrd ===*/
	$('#confrm-pwd').on('keyup', function () {
		if ($('#new-pwd').val() === $('#confrm-pwd').val()) {
			$("#new-pwd").removeClass("pwd-not-matched");
			$("#confrm-pwd").removeClass("pwd-not-matched");
			$(".pwd-error").removeClass("show-error");
			//            $(".pwd-error").addClass("pwd-matched pwd-accept");
			//            $(".pwd-error").removeClass("pwd-error");
		} else {
			$("#confrm-pwd").addClass("pwd-not-matched");
			$("#new-pwd").addClass("pwd-not-matched");
			$(".pwd-error").addClass("show-error");
		}
	});

	/*======modal popup starts=========*/ 

	$(".signinlabel-mobile").click(function () {
		$(".signin-box").show();
		$(".signinlabel-mobile").hide();
	});
	$(".mb-signin-close .close").click(function () {
		$(".signin-box").hide();
		$(".signinlabel-mobile").show();
	});

	$(".resetlabel-mobile").click(function () {
		$(".signin-box").hide();
		$(".reset-box").show();
		// $(".resetlabel-mobile").hide();
	});
	$(".mb-signin-close .close").click(function () {
		$(".reset-box").hide();
		$(".resetlabel-mobile").show();
	});
	$(".reset-label").click(function () {
		$(".signin-box").css("display", "none");
		$(".signup-modal-footer").css("display", "none");
		// $(".reset-password-modal-footer").css("display", "none");
		
	});

	/*=====modal popup selected text color=====*/ 

		$(".modal-close,.modal").click(function () {
		$(".navbar__navlink.text-gold-selected").removeClass("text-gold");
	});
	$(".reset-label").click(function () {
		$(".navbar__navlink.text-gold-selected").addClass("text-gold");

	});

	/*=================modalpopup ends==========*/

	/*=======Hover Class for Slie in accordion====*/
	$(".slide-container .slides").click(function () {
		$(this).addClass("slide-selected").siblings().removeClass("slide-selected slide-not-hovered");
		$(this).siblings().find(".video-wrapper").css('display', 'none');
		$(this).siblings().find(".strip-details").css('display', 'none');
		$(this).siblings().find(".slide-bg").css('display', 'block');
		// $(".watchlist-position").show();
		if($(".slides.slide-selected .video-wrapper").is(":visible")){
			$(this).find(".strip-details").css('display', 'none');	
			// $(".watchlist-position").hide();
		}else{
			$(this).find(".strip-details").css('display', 'block');
			// $(".watchlist-position").show();
		}
	});
	$(".slide-container .slides").mouseover(function () {
		if (!($(this).hasClass("slide-selected"))) {
			$(this).addClass("slide-hovered").siblings().addClass("slide-not-hovered");
		}
	});
	$(".slide-container .slides").mouseout(function () {
		$(this).removeClass("slide-hovered").siblings().removeClass("slide-not-hovered");
	});
	/* $(".swiper-slide .play-btn").click(function () {
	     $(".more-info-section").toggle();
	 });*/
	$("section.box-bg-grey .container-custom .close-btn").on('click',function (e) {
		
	
		$(this).parents('.swiper-container').find('.swiper-custom-pagination-desktop div[class^=swiper-button-]').removeClass('new-pos');
		$(this).parents('.swiper-container').find('.swiper-custom-pagination-desktop').removeClass('new-pos');
		$(".container-custom.more-info-container").hide();
		$('.swiper-slide.active').removeClass('active');
		/*$('html,body').animate({
			scrollTop:$(this).parents('.swiper-container').offset().top-$(this).parents('.swiper-container').height()
		},10);*/
	});
	var userAgent, ieReg, ie,matchIE;
	userAgent = window.navigator.userAgent;
	ieReg = /msie|Trident.*rv[ :]*11\./gi;
	ie = ieReg.test(userAgent);
	matchIE = /MSIE\s([\d.]+)/
	if(ie || matchIE) {
	  $(".hero-landing-imgblock").each(function () {
		  //debugger;
		var $container = $(this),
			imgUrl = $(this).find("source").attr("srcset");
		if (imgUrl) {
		  $container.css("backgroundImage", 'url(' + imgUrl + ')').addClass("custom-object-fit");
		}
	  });
	}
	$(".strip-details .play-series,.strip-details .icon-play").click(function (e) {
		
		if ($(window).width() < 768) {
			$(this).parents('.slides').find(".video-wrapper").show()
			$(".slide-selected .strip-details").show();
			$(".slide-selected .slide-bg").hide();
		}
		else {
			$(this).parents('.slides').find(".video-wrapper").show();
			$(".slide-selected .strip-details").hide();
			$(".slide-selected .slide-bg").hide();
			// $(".watchlist-position").hide();
		}
		e.stopPropagation();
		// 	if(!($(".watchlist-position").is(":visible"))){
		// debugger;
		// $(document).on('click', '.add-to-watchlist', function () {
		// 	//setTimeout('$(".watchlist-position").hide()',1500);
		// 	$(".watchlist-position").show();
		// 	$(".watchlist-position").delay(2000).fadeOut("slow");
		// });			
		// }
	});
	$(document).on('click', '.slides.slide-selected .close-btn', function () {
		$(".video-wrapper").hide();
		$(".slide-selected .strip-details").show();
		$(".slide-selected .slide-bg").show();
		// $(".watchlist-position").show();
	});
	$(".image-block-large .play-btn").click(function () {
		if ($(window).width() < 768) {
			$(".video-wrapper").show();
			$(".landing-details").hide();
		} else {
			$(".video-wrapper").show();
			$(".series-details-main").hide();
			$(".landing-details").hide();
			// $(".watchlist-position").hide();
		}
	});
	$(".image-block-large .close-btn").click(function () {
		$(".series-details-main").show();
		$(".video-wrapper").hide();
		$(".landing-details").show();
		// $(".watchlist-position").show();
	});

	// details page show and hide video
	$(".vid-link .play-btn").click(function () {
			$(this).parent().parent().addClass("play-video");
	});
	/* Ashwini */
	$(".add-series-play").on('click', function (event) {
		event.stopPropagation();
		$(this).toggleClass("clicked");
	});
	$(".ae-button-series-watchlist").on('click', function (event) {
		event.stopPropagation();
		$(this).find(".add-series-play").toggleClass("clicked");
	});
	
	$(".wl-play-series-trailer").on('click', function (event) {
		$(this).toggleClass("clicked");
		if ($(".wl-play-series-trailer").hasClass('clicked')) {
			$(".watch-series-trailer-container").show();
		}
		else {
			$(".watch-series-trailer-container").hide();
		}
	});
	$('.scripted-page .mini-box-title.text-uppercase >  .title-landing').on('click', function (event) {
		event.stopPropagation();
		window.open('scripted-details.html', '_self');
	});
	$('.factual-page .mini-box-title.text-uppercase >  .title-landing').on('click', function (event) {
		event.stopPropagation();
		window.open('factual-details.html', '_self');
	});
	$('.formats-page .mini-box-title.text-uppercase >  .title-landing').on('click', function (event) {
		event.stopPropagation();
		window.open('formats-details.html', '_self');
	});
	$('.movies-page .mini-box-title.text-uppercase >  .title-landing').on('click', function (event) {
		event.stopPropagation();
		window.open('movie-details.html', '_self');
	});

	/* Ashwini */
// scripted details cast more info 
$(document).on('click','.cast-info-notselected',function(){
	$(this).parents('.cast-thumbnail').toggleClass("cast-clicked").siblings().removeClass("cast-clicked");
	$(this).parents('.details-cast-thumbnail-wrapper').addClass("details-cast-thumbnail-wrapper-selected").siblings().removeClass("details-cast-thumbnail-wrapper-selected");
	if($(".cast-thumbnail").hasClass("cast-clicked")){
	$(".details-cast-thumbnail-wrapper.details-cast-thumbnail-wrapper-selected .cast-more-info-container").show();
	var moreinfowidth=$(".details-cast-thumbnail-wrapper").outerWidth();
	$(".cast-more-info-container").css("width",moreinfowidth);
	var slideheight=$(".cast-thumbnail").outerHeight();
	var moreinfoheight=$(".cast-more-info-container").outerHeight();
	$(".cast-thumbnail").css("margin-bottom",0);
	$(".cast-thumbnail.cast-clicked").css("margin-bottom",moreinfoheight);
	var wlmargin=$(".cast-clicked").offset().top - $(".details-cast-thumbnail-wrapper").offset().top;
	$(".cast-more-info-container").css("margin-top",wlmargin+slideheight);
	}else{
		$(".details-cast-thumbnail-wrapper.details-cast-thumbnail-wrapper-selected .cast-more-info-container").hide();
		$(".cast-thumbnail").css("margin-bottom",0);
		$(".cast-more-info-container").css("margin-top",0);
	}
});
//scripted details cast more info close
$(document).on('click','.crew-info-block .close-btn',function(){
	$('.cast-clicked .cast-more-info-container').removeClass("show-cast-info");
	$('.cast-clicked').css("margin-bottom","0");
	$(".cast-clicked").parent().removeClass("show-more-info");
	$(".headshot-details-container").parent().removeClass("cast-clicked");
	$(".cast-more-info-container").hide();
	
 });
	 $(".swiper-slide-image").click(function () {
		 event.preventDefault() ;
		$(this).parent().addClass("selected").siblings().removeClass("selected");
		var id=$('.swiper-slide.selected').attr('href');
		$(id).parent().addClass('active').siblings().removeClass('active');
	 });      
	
	// $(".ae-button-watch-trailer").click(function () {
	// 	$(".ae-button-watch-trailer .watch-series-trailer").toggleClass("clicked");
	// 	if ($(".watch-series-trailer").hasClass('clicked')) {
	// 		$(".watch-series-trailer-container").show();
	// 	}
	// 	else {
	// 		$(".watch-series-trailer-container").hide();
	// 	}
	// });
	

	$(".image-block-mini").click(function () {

		$(this).addClass("selected").siblings().removeClass("selected");
	});
	$('.series-details-landing-mini').on('click', function (event) {
		event.stopPropagation();
		//return false;
	});

	$(document).on('click', '.prev-arrow-hero', function () {
		$(this).parents('.strip-details').hide();
		$(this).parents('.slides').prev().children('.strip-details').show();
		$(this).parents('.slides').prev().addClass("slide-selected");
		$(this).parents('.slides').removeClass("slide-selected");

	});
	$(document).on('click', '.next-arrow-hero', function () {
		$(this).parents('.strip-details').hide();
		$(this).parents('.slides').next().children('.strip-details').show();
		$(this).parents('.slides').next().addClass("slide-selected");
		$(this).parents('.slides').removeClass("slide-selected");
	});
	$(document).on('click', '.prev-arrow-hero-xs', function () {
		$(".slides.slide-selected .strip-details").show();
		$('.next-arrow-hero-xs').show();
		var currentSlidePrev = $(".slides.slide-selected").index();
		$(".current-slide").text('0' + currentSlidePrev);
		if (currentSlidePrev === 1) {
			$('.prev-arrow-hero-xs').hide();

		}
		$(".slides").eq(currentSlidePrev - 1).addClass("slide-selected");
		$(".slides").eq(currentSlidePrev).removeClass("slide-selected");

	});
	if ($(".slides.slide-selected").index() === 5) {
		$('.next-arrow-hero-xs').hide();
	}
	if ($(".slides.slide-selected").index() === 0) {
		$('.prev-arrow-hero-xs').hide();
	}
	$(document).on('click', '.next-arrow-hero-xs', function () {
		$(".slides.slide-selected .strip-details").show();
		$('.prev-arrow-hero-xs').show();
		var currentSlideNext = $(".slides.slide-selected").index();
		if (currentSlideNext == 5) {
			$('.next-arrow-hero-xs').hide();
		}
		else {
			$('.next-arrow-hero-xs').show();
		}
		var currentSlideNext = $(".slides.slide-selected").index();
		var test = currentSlideNext + 2;
		$(".current-slide").text('0' + test);
		if (currentSlideNext + 1 === 5) {
			$('.next-arrow-hero-xs').hide();

		}
		$(".slides").eq(currentSlideNext + 1).addClass("slide-selected");
		$(".slides").eq(currentSlideNext).removeClass("slide-selected");

	});
	/*=====Landing Page Hero====*/
	$(document).on('click', '.hero-landing-section .prev-arrow-hero-xs', function () {
		$('.next-arrow-hero-xs').show();
		var currentSlidePrev = $(".image-block-large.active.in").index();
		$(".current-slide").text('0' + currentSlidePrev);
		if (currentSlidePrev === 1) {
			$('.prev-arrow-hero-xs').hide();

		}
		$(".image-block-large").eq(currentSlidePrev - 1).addClass("active in");
		$(".image-block-large").eq(currentSlidePrev).removeClass("active");

	});
	if ($(".image-block-large.active").index() === 3) {
		$('.next-arrow-hero-xs').hide();
	}
	if ($(".image-block-large.active").index() === 0) {
		$('.prev-arrow-hero-xs').hide();
	}
	$(document).on('click', '.hero-landing-section .next-arrow-hero-xs', function () {
		$('.prev-arrow-hero-xs').show();
		var currentSlideNext = $(".image-block-large.active").index();
		if (currentSlideNext == 5) {
			$('.next-arrow-hero-xs').hide();
		}
		else {
			$('.next-arrow-hero-xs').show();
		}
		var currentSlideNext = $(".image-block-large.active").index();
		var test = currentSlideNext + 2;
		$(".current-slide").text('0' + test);
		if (currentSlideNext + 1 === 3) {
			$('.next-arrow-hero-xs').hide();

		}
		$(".image-block-large").eq(currentSlideNext + 1).addClass("active in");
		$(".image-block-large").eq(currentSlideNext).removeClass("active");

	});
	/*=====Landing Page Hero Ends====*/
	
  
	$('.swiper-slide-image .play-btn').on('click', function (e) {
		//e.stopPropagation();
		var self = $(this);
		var element = $(this).parents('.swiper-slide').closest('section').attr('class');
		element = element.split(" ").join('.');

		//if ($(window).width() > 991) {
			swiperMoreInfoBlock(self, element);
		//}
		

	});
	/*====Footer POP UP =====*/
	$(document).on('click', '.footer-links .sigin-in-footer', function () {
		$(".sign-up-box").addClass("footer-signin");
	})
	/*===Footer Pop Up Ends====*/
	$(document).on('click', '#login-signin', function () {
		var username = document.forms["loginform"]["username"].value;
		var password = document.forms["loginform"]["password"].value;
		if (username == "") {
			$(".modal-body .form-control.input-username").addClass("validation-error")
		}
		if (password == "") {
			$(".modal-body .form-control.input-password").addClass("validation-error")
		}
		else {
			$(".sigin-header-label, .signedout-visible").css("display", "none");
			$(".sigin-header-label").removeClass("text-fade");
			$(".signout-link-header, .signed-in-visible").css("display", "block");
			$(".signout-link-header").addClass("text-fade");
			$(".signup-modal").css("display", "none");
			$(".modal-body .form-control.input-password").removeClass("validation-error");
			$(".modal-body .form-control.input-username").removeClass("validation-error")
		}
	});
	$(document).on('click', '.signout-link-header', function () {
		$(".signout-link-header,.signed-in-visible").css("display", "none");
		$(".sigin-header-label,.signedout-visible").css("display", "block");
	});
	$(document).on('click', '#signin-sm-xs', function () {
		var usernamesm = document.forms["form-sm-xs"]["username-sm-xs"].value;
		var passwordsm = document.forms["form-sm-xs"]["pwd-sm-xs"].value;
		if (usernamesm == "") {
			$(".form-control.input-username").addClass("validation-error")
		}
		if (passwordsm == "") {
			$(".form-control.input-password").addClass("validation-error")
		}
		else {
			$(".signin-label-sm-xs").css("display", "none");
			$(".signout-label-sm-xs").css("display", "block");
			$(".navbar-toggle").removeClass("active");
			$(".navbar-collapse.collapse.in").removeClass("in");
			$(".signin-box-sm-xs").css("display", "none");
			$(".form-control.input-password").removeClass("validation-error");
			$(".form-control.input-username").removeClass("validation-error");
			 $('body').removeClass('menu-open');
			 $('.overlay-toggle-body').hide();
		}
	});
	$(document).on('click', '.signout-label-sm-xs', function () {
		$(".signin-label-sm-xs").css("display", "none");
		$(".signout-label-sm-xs").css("display", "none");
		$(".signin-box-sm-xs").css("display", "block");
		$(".navbar-collapse.collapse.in").removeClass("in");
		$(".navbar-toggle").removeClass("active");
		$(".signinlabel-mobile").show();
		$('body').removeClass('menu-open');
		$('.overlay-toggle-body').hide();
	});
	$(document).on('click', '.signin-box-sm-xs .modal-close', function () {
		$(".signin-label-sm-xs").show();
	});
	/*=====mobile and tablet user not signed in =====*/
	// if ($(window).width() < 992) {
	// 	$(".nav-sm li,.user-not-signed-in").click(function(){
	// 		$(".navbar-toggle").addClass("active");
	// 		$(".navbar-collapse").addClass("in");
	// 		$(".form-control.input-username").addClass("validation-error");
	// 		$('#navbar').animate({scrollTop: 378}, 600);
	// 		$('body').addClass('menu-open');
	// 	});
	// }
	/*======Search Results===*/
	$(document).on('click', '#advanced-btn', function () {
		$("#search-toggle").toggle();
		$(".btn-close").toggle();
	});
	$(document).on('click', '.search-filter-wrapper .close-btn', function () {
		$("#search-toggle").hide();
		$(".btn-close").hide();
	});
	/*======Search Results Ends===*/
	/*====Watchlist Script=====*/
		$(document).on('click', '#createnew-wl-btn', function () {
		$("#create-new-wl").hide();
		$("#watchlist-list-block").hide();
		$("#creating-nw-wl").show();
	});
		$(document).on('click', '#creating-wl', function () {
			if($('.autosearch-input-wl')[0].value == ''){
				$(".autosearch-input-wl").addClass("validation-error");
			}
			else{
		$("#create-new-wl").show();
		$("#watchlist-list-block").show();
		$("#creating-nw-wl").hide();
			}
	});
	/*====Watchlist Script Ends=====*/
	// function wlitemClickedOddTimes(){
		
		
	// }
	// function wlitemClickedEvenTimes(){
		
	// }
	$(document).on('click', '.listitems', function () {
		$(".k-panelbar li.k-state-default .k-link.k-state-selected").toggleClass("listitem-selected");
	});
	

	/** Watchlist swiper Starts **/
	/*var watchlistSwiper = $('.wl-episode-swiper-wrapper .swiper-container.episode-aswiper-two');
	var swiperWatchlist = new Swiper(watchlistSwiper, {
			pagination: '.swiper-pagination',
			nextButton: '.swiper-button-next',
			prevButton:'.swiper-button-prev',
			slidesPerView: 4,
			centeredSlides: false,
			//slidesOffsetBefore:-450,
			slidesOffsetAfter:340,
			paginationType: 'custom',
			paginationClickable: true,
			observer: false,
			spaceBetween: 15,
			grabCursor: true,
			resizeReInit: true,
			initialSlide: 0,
			onSlideChangeStart: function (swiperWatchlist) {
				watchlistSwiper.find('.swiper-custom-pagination-desktop').removeClass('new-pos');
				watchlistSwiper.find('.swiper-custom-pagination-desktop div[class^=swiper-button-]').removeClass('new-pos');
				$('.container-custom.more-info-container').hide();
				watchlistSwiper.find('.swiper-slide.active').removeClass('active');
				
				if ($(window).width() > 991) {
					watchlistSwiper.find('.swiper-custom-pagination-desktop div[class^=swiper-button-next]').css('right','0.75%');
					watchlistSwiper.find('.swiper-wrapper').css('padding-left','60px');
					watchlistSwiper.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
					if (watchlistSwiper.find('.swiper-slide-active').index() == 1) {

						setTimeout(function () {
							
							$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
							$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
							
						}, 0);
					} else if (watchlistSwiper.find('.swiper-slide-active').index() == 2) {

						setTimeout(function () {

							$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
							$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
							
						}, 0);

					}
					else if (watchlistSwiper.find('.swiper-slide-active').index() > 2) {
						setTimeout(function () {

							$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
							$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
							
							if (watchlistSwiper.find('.swiper-slide-active').index() == (watchlistSwiper.find('.swiper-slide').length - 4)) {
								watchlistSwiper.find('.swiper-button-next').show();
								if(swiperWatchlist.params.slidesOffsetAfter==340){
								
									swiperWatchlist.params.slidesOffsetAfter=360;
									if ($(window).width() >= 1600) {
				
										swiperWatchlist.params.slidesOffsetAfter=400;
									}
									swiperWatchlist.update();
								}
							
							}
							
							else if (watchlistSwiper.find('.swiper-slide-active').index() == (watchlistSwiper.find('.swiper-slide').length - 3)) {
								watchlistSwiper.find('.swiper-button-next').hide();
							}
							else {
								watchlistSwiper.find('.swiper-button-next').show();
							}

						}, 0);


					}
					else if (watchlistSwiper.find('.swiper-slide-active').index() == 0) {
				
						watchlistSwiper.find('.swiper-custom-pagination-desktop div[class^=swiper-button-next]').css('right','4.75%');
						setTimeout(function () {
							
								$('.swiper-slide-active,.swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
								
								watchlistSwiper.find('.swiper-wrapper').css('padding-left','0');
								swiperWatchlist.setWrapperTranslate(60, 0, 0);
								if (window.matchMedia('(min-width:769px) and (max-width: 1024px) and (orientation:landscape)').matches){
								//console.log('sa..');
								//setTimeout(function () {
									swiperWatchlist.setWrapperTranslate(30, 0, 0);
								//},0);
								}
							}, 0);
							
							
						

					}


				}
				
			},
			breakpoints: {
				1440:{
					slidesPerView: 4,
					spaceBetween: 15,
					centeredSlides: false,
					slidesOffsetAfter:360
				},
				1024: {
					slidesPerView: 4,
					spaceBetween: 15,
					centeredSlides: false,
					slidesOffsetAfter:360
				},
				991: {
					slidesPerView: 2,
					spaceBetween: 15,
					centeredSlides: false,
					slidesOffsetAfter: 0,
					paginationCustomRender: function (swiperWatchlist, current, total) {
						if (current.toString().length == 1 && current == '9') {
                          //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          if((swiperWatchlist.slides.length).toString().length == 1){
							
						    watchlistSwiper.find('.swiper-pagination').html('0' + current + '-' + (current + 1) + '<span class="pagination-seperator">/</span>' + '0' + swiperWatchlist.slides.length);
                            //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          }
                          else if((swiperWatchlist.slides.length).toString().length >= 2){
                            //return '0' + current + '-' + (current + 1) + '/' + swiper.slides.length;
							 watchlistSwiper.find('.swiper-pagination').html('0' + current + '-' + (current + 1) + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
                          }
                        } 

						else if (current.toString().length == 1) {
						  if((swiperWatchlist.slides.length).toString().length  == 1){
							//return '0' + current + '-' + '0' + (current + 1) + '/'+'0' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination').html('0' + current + '-' + '0' + (current + 1) + '<span class="pagination-seperator">/</span>' +'0' + swiperWatchlist.slides.length);
						  }
						  else if((swiperWatchlist.slides.length).toString().length  >= 2){
							
							
							//return '0' + current + '-' + '0' + (current + 1) + '/' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html('0' + current + '-' + '0' + (current + 1) + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
						  }
						}
						else if (current.toString().length >= 2) {
							
							
							//return current + '-' + (current + 1) + '/'+ swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html(current + '-' + (current + 1) + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
						}

					}
				},
				767: {
					slidesPerView: 1,
					spaceBetween: 30,
					centeredSlides: true,
					slidesOffsetAfter: 0,
					
					paginationCustomRender: function (swiperWatchlist, current, total) {
						if (current.toString().length == 1 && current == '9') {

                            //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          if((swiperWatchlist.slides.length).toString().length == 1){
                            //return '0' + current  + '/' + '0' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html('0' + current  + '<span class="pagination-seperator">/</span>' + '0' + swiperWatchlist.slides.length);
							
                          }
                          else if((swiperWatchlist.slides.length).toString().length >= 2){
                           // return '0' + current + '/' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
                          }
                        } else if (current.toString().length == 1) {



                            //return '0' + current + '-' + '0' + (current + 1) + '/' + '0' + swiper.slides.length;
                            if((swiperWatchlist.slides.length).toString().length == 1){
                               // return '0' + current + '/' + '0' + swiper.slides.length;
								watchlistSwiper.find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + '0' + swiperWatchlist.slides.length);
                              }
                              else if((swiperWatchlist.slides.length).toString().length >= 2){
                               // return '0' + current + '/' + swiper.slides.length;
								watchlistSwiper.find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
                              }
                        } else if (current.toString().length >= 2) {
                            //return current  + '/' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html(current  + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
                        }

					  }
					
				},
				320: {
					slidesPerView: 1,
					spaceBetween: 30,
					centeredSlides: true,
					slidesOffsetAfter: 0,
					paginationCustomRender: function (swiperWatchlist, current, total) {
						if (current.toString().length == 1 && current == '9') {

                            //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          if((swiperWatchlist.slides.length).toString().length == 1){
                            //return '0' + current  + '/' + '0' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html('0' + current  + '<span class="pagination-seperator">/</span>' + '0' + swiperWatchlist.slides.length);
							
                          }
                          else if((swiperWatchlist.slides.length).toString().length >= 2){
                           // return '0' + current + '/' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
                          }
                        } else if (current.toString().length == 1) {



                            //return '0' + current + '-' + '0' + (current + 1) + '/' + '0' + swiper.slides.length;
                            if((swiperWatchlist.slides.length).toString().length == 1){
                               // return '0' + current + '/' + '0' + swiper.slides.length;
								watchlistSwiper.find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + '0' + swiperWatchlist.slides.length);
                              }
                              else if((swiperWatchlist.slides.length).toString().length >= 2){
                               // return '0' + current + '/' + swiper.slides.length;
								watchlistSwiper.find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
                              }
                        } else if (current.toString().length >= 2) {
                            //return current  + '/' + swiper.slides.length;
							watchlistSwiper.find('.swiper-pagination ').html(current  + '<span class="pagination-seperator">/</span>' + swiperWatchlist.slides.length);
                        }


					}
				}
			}
	});*/
	
	/** Watchlist swiper ends **/

	
	$(document).on('click','.watchlist-wrapper .wl-slide .icon-plus',function(){
		$(this).parents('.wl-slide').toggleClass("wl-selected").siblings().removeClass("wl-selected");
		$(this).parents('.wl-container').addClass("wl-container-selected").siblings().removeClass("wl-container-selected");
		if($(".wl-slide").hasClass("wl-selected")){
		$(".wl-container.wl-container-selected .more-info-wl").show();
		var moreinfowidth=$(".watchlist-wrapper").outerWidth();
		$(".detail-block-wl").css("width",moreinfowidth);
		var slideheight=$(".wl-slide").outerHeight();
		var moreinfoheight=$(".detail-block-wl").outerHeight();
		$(".wl-slide").css("margin-bottom",0);
		$(".wl-selected.wl-slide").css("margin-bottom",moreinfoheight);
		var wlmargin=$(".wl-selected").offset().top - $(".watchlist-wrapper").offset().top;
		$(".detail-block-wl").css("margin-top",wlmargin+slideheight);
		}else{
			$(".wl-container.wl-container-selected .more-info-wl").hide();
			$(".wl-slide").css("margin-bottom",0);
			$(".detail-block-wl").css("margin-top",0);
		}

		setTimeout(function(){
			window.swiper.update();
		},0);

		// var wlselection = this;
		// return (wlselection.t = !wlselection.t) ? wlitemClickedOddTimes(wlselection) : wlitemClickedEvenTimes(wlselection);
		//return $(this).hasClass('wlitemclicked') ? wlitemClickedOddTimes(this) : wlitemClickedEvenTimes(this);
	});
	$(document).on('click','.wl-btn-row #wl-play-sereistrailer',function(){
		$(this).parents('.wl-slide').toggleClass("wl-selected").siblings().removeClass("wl-selected");
		$(this).parents('.wl-container').addClass("wl-container-selected").siblings().removeClass("wl-container-selected");
		if($(".wl-slide").hasClass("wl-selected")){
		$(".wl-container.wl-container-selected .more-info-wl").show();
		var moreinfowidth=$(".watchlist-wrapper").outerWidth();
		$(".detail-block-wl").css("width",moreinfowidth);
		var slideheight=$(".wl-slide").outerHeight();
		var moreinfoheight=$(".detail-block-wl").outerHeight() + 40;
		$(".wl-slide").css("margin-bottom",0);
		$(".wl-selected.wl-slide").css("margin-bottom",moreinfoheight);
		var wlmargin=$(".wl-selected").offset().top - $(".watchlist-wrapper").offset().top;
		$(".detail-block-wl").css("margin-top",wlmargin+slideheight);
		}else{
			$(".wl-container.wl-container-selected .more-info-wl").hide();
			$(".wl-slide").css("margin-bottom",0);
			$(".detail-block-wl").css("margin-top",0);
		}

		setTimeout(function(){
			window.swiper.update();
		},0);

		// var wlselection = this;
		// return (wlselection.t = !wlselection.t) ? wlitemClickedOddTimes(wlselection) : wlitemClickedEvenTimes(wlselection);
		//return $(this).hasClass('wlitemclicked') ? wlitemClickedOddTimes(this) : wlitemClickedEvenTimes(this);
	});
	$(document).on('click','.watch-series-trailer .play-btn',function(){
		$(this).parents('.wl-slide').toggleClass("wl-selected").siblings().removeClass("wl-selected");
		$(this).parents('.wl-container').addClass("wl-container-selected").siblings().removeClass("wl-container-selected");
		if($(".wl-slide").hasClass("wl-selected")){
		$(".wl-container.wl-container-selected .more-info-wl").show();
		var moreinfowidth=$(".watchlist-wrapper").outerWidth();
		$(".detail-block-wl").css("width",moreinfowidth);
		var slideheight=$(".wl-slide").outerHeight();
		var moreinfoheight=$(".detail-block-wl").outerHeight() + 40;
		$(".wl-slide").css("margin-bottom",0);
		$(".wl-selected.wl-slide").css("margin-bottom",moreinfoheight);
		var wlmargin=$(".wl-selected").offset().top - $(".watchlist-wrapper").offset().top;
		$(".detail-block-wl").css("margin-top",wlmargin+slideheight);
		}else{
			$(".wl-container.wl-container-selected .more-info-wl").hide();
			$(".wl-slide").css("margin-bottom",0);
			$(".detail-block-wl").css("margin-top",0);
		}

		setTimeout(function(){
			window.swiper.update();
		},0);

		// var wlselection = this;
		// return (wlselection.t = !wlselection.t) ? wlitemClickedOddTimes(wlselection) : wlitemClickedEvenTimes(wlselection);
		//return $(this).hasClass('wlitemclicked') ? wlitemClickedOddTimes(this) : wlitemClickedEvenTimes(this);
	});
	$(document).on('click','.more-info-section .close-button .close-btn',function(){
		$(this).parents('.wl-slide').toggleClass("wl-selected").siblings().removeClass("wl-selected");
		$(this).parents('.wl-container').addClass("wl-container-selected").siblings().removeClass("wl-container-selected");
		if($(".wl-slide").hasClass("wl-selected")){
		$(".wl-container.wl-container-selected .more-info-wl").show();
		var moreinfowidth=$(".watchlist-wrapper").outerWidth();
		$(".detail-block-wl").css("width",moreinfowidth);
		var slideheight=$(".wl-slide").outerHeight();
		var moreinfoheight=$(".detail-block-wl").outerHeight() + 40;
		$(".wl-slide").css("margin-bottom",0);
		$(".wl-selected.wl-slide").css("margin-bottom",moreinfoheight);
		var wlmargin=$(".wl-selected").offset().top - $(".watchlist-wrapper").offset().top;
		$(".detail-block-wl").css("margin-top",wlmargin+slideheight);
		}else{
			$(".wl-container.wl-container-selected .more-info-wl").hide();
			$(".wl-slide").css("margin-bottom",0);
			$(".detail-block-wl").css("margin-top",0);
		}

		setTimeout(function(){
			window.swiper.update();
		},0);

		// var wlselection = this;
		// return (wlselection.t = !wlselection.t) ? wlitemClickedOddTimes(wlselection) : wlitemClickedEvenTimes(wlselection);
		//return $(this).hasClass('wlitemclicked') ? wlitemClickedOddTimes(this) : wlitemClickedEvenTimes(this);
	});
	$("#wl-clear").click(function () {
		$(this).parent().find('input[type=text].autosearch-input-wl').val('');
	});
	$(".icon-edit").click(function () {
	$(this).addClass("selected");
	$("#wl-slides").hide();
	$("#wl-list-items").show();
	$("#showonedit-wl").show();
	$(".main-wl-name").addClass("edit-mode-on");
	$(".icon-input-edit").show();
	$('.main-wl-name').prop('contenteditable', function(i, val) {
		return val == "true" ? false : true;
	});
	$("#showonedit-wl button").click(function () {
		$(".icon-edit").removeClass("selected");
		$("#wl-slides").show();
		$("#wl-list-items").hide();
		$("#showonedit-wl").hide();
		$(".main-wl-name").removeClass("edit-mode-on");
		$('.main-wl-name').prop('contenteditable', function(i, val) {
			return val == "true" ? true : false;
		});
		$(".icon-input-edit").hide();
	});
	
	});
	$(".icon-duplicate").click(function () {
		$(".create-copy").css('display','inline-block');
	});
		$(document).on('click', '.listitems', function () {
			$(this).parents(".k-panelbar").toggleClass("listitem-clicked")
		});
		$(document).on('click', '.share-watchlistpopover .close-btn', function () {
			$(".overlay-body").hide();
			$(".share-watchlistpopover").hide();
		});
		$(document).on('click', '.share-watchlistpopover .share-wl-btn', function () {
			$(".share-watchlistpopover").hide();
			$(".overlay-body").hide();
		});
		$(document).mouseup(function (e) {
			$(document).on('click', '.icon-share', function () {
			$(".share-watchlistpopover").toggle();
			$(".overlay-body").toggle();
				});
				var container = $(".share-watchlistpopover");
		
				if (!container.is(e.target) // if the target of the click isn't the container...
					&& container.has(e.target).length === 0) // ... nor a descendant of the container
				{
					container.hide();
					$(".overlay-body").hide();                                    
				}
				else {
					container.show();
				}
			});
			$(document).mouseup(function (e) {
				$(document).on('click', '.icon-delete', function () {
					$(this).toggleClass("selected");
				$(".delete-watchlistpopover").toggle();
				//$(".overlay-body").toggle();
					});
					var container = $(".delete-watchlistpopover");
			
					if (!container.is(e.target) // if the target of the click isn't the container...
						&& container.has(e.target).length === 0) // ... nor a descendant of the container
					{
						container.hide();
						$(".icon-delete").removeClass("selected");
						//$(".overlay-body").hide();                                    
					}
					else {
						container.show();
						$(".icon-delete").addClass("selected");
					}
				});
				
				/** swiper press page **/
				
				var swiperModal = new Swiper('.aswiper-two-modal',{
						pagination: '.swiper-pagination-modal',
						nextButton: '.swiper-button-next',
						prevButton: '.swiper-button-prev',
						slidesPerView: 1,
						//calculateHeight:true,
						centeredSlides: true,
						paginationClickable:true,
						initialSlide:0,
						autoHeight:true,
						onSlideChangeStart  : function(){
							setTimeout(function(){

								$('#myModalSwiper').css('height',  $('.'+swiperModal.slides[swiperModal.activeIndex].getAttribute('class').split(' ')[1]).height() + $('#myModalSwiper .modal-body').offset().top + 50);
								$('#myModalSwiper .modal-body').css('height', $('.'+swiperModal.slides[swiperModal.activeIndex].getAttribute('class').split(' ')[1]).height() + 50);
								$('.swiper-container.aswiper-two-modal').height($('.'+swiperModal.slides[swiperModal.activeIndex].getAttribute('class').split(' ')[1]).height());
								 swiperModal.update();
							},10);
							
						},
						breakpoints:{
							767 : {
								slidesPerView: 1,
								centeredSlides: true,
								spaceBetween:40
							
							}
						
						}
						
				
				});
			
				$('.press-block').parent().on('click',function(){
					$('#myModalSwiper').modal({backdrop: 'false', keyboard: false,show: true});
					//rescale();
					$('.modal-open').animate({scrollTop:0}, 0);
					swiperModal.params.autoHeight = true;
					swiperModal.update();
					swiperModal.slideTo($(this).index(),false );
					rescale(swiperModal);
				});
				
				/** swiper press page **/
				
				swiperCarousel();
							

});
function rescale(swiperModal){


    var offsetBody = 50;
	setTimeout(function(){
		$('#myModalSwiper').css('height', $('.'+swiperModal.slides[swiperModal.activeIndex].getAttribute('class').split(' ')[1]).height() +  $('#myModalSwiper .modal-body').offset().top + offsetBody  );
		$('#myModalSwiper .modal-body').css('height', $('.'+swiperModal.slides[swiperModal.activeIndex].getAttribute('class').split(' ')[1]).height());
   
	},0);
 
}

function swiperMoreInfoBlock(self, element) {
	//var moreInfoPosition;
	//var swiperHeight;
	//var headingContainerHeight;
	self.parents('.swiper-slide').closest('.' + element).siblings().find('.container-custom.more-info-container').hide();
	self.parents('.swiper-slide').closest('.' + element).siblings().find('.swiper-slide.active').removeClass('active');
	var deviceWidth = $(window).width();
	var playBtnOffset = self.parents('.swiper-slide').find('.play-btn').offset().left;
	var leftPosArrow = playBtnOffset-55;
	//var leftPosArrow = self.parents('.swiper-slide').offset().left + self.parents('.swiper-slide').closest('.swiper-container').offset().left + slideWidth;
	self.parents('.swiper-slide').closest('.' + element).find('.arrow').css('left', ((leftPosArrow / deviceWidth) * 100) + '%');
	$(window).on('resize',function(){
		var deviceWidth = $(window).width();
		setTimeout(function(){
			if($(document).find('.swiper-slide').hasClass('active')){
				var playBtnOffset = $('.swiper-slide.active').find('.play-btn').offset().left;
			}
			var leftPosArrow = playBtnOffset-55;
			self.parents('.swiper-slide').closest('.' + element).find('.arrow').css('left', ((leftPosArrow / deviceWidth) * 100) + '%');
		},0);
	});



	if (!self.parents('.swiper-slide').hasClass('active')) {
		self.parents('.swiper-slide').siblings().removeClass('active');
		self.parents('.swiper-slide').addClass('active');
		self.parents('.swiper-slide').closest('.' + element).find('.swiper-custom-pagination-desktop').addClass('new-pos');
		self.parents('.swiper-slide').closest('.' + element).find('.swiper-custom-pagination-desktop div[class^=swiper-button-]').addClass('new-pos');
		self.parents('.swiper-slide').closest('.' + element).find('.container-custom.more-info-container').show();
		//moreInfoPosition =  self.parents('.swiper-slide').closest('.' + element).find('.container-custom.more-info-container').offset().top;
		//swiperHeight = (self.parents('.swiper-slide').parents('.swiper-wrapper').height())/1.8;
		//headingContainerHeight = self.parents('.swiper-slide').closest('.' + element).find('.container-lg').height();
		//alert(self.parents('.swiper-slide').parents('.swiper-wrapper').height());
		//alert('1 '+ self.parents('.swiper-slide').closest('.' + element).find('.container-custom.more-info-container').offset().top);
		//$('html,body').animate({
		//	scrollTop: self.parents('.swiper-slide').closest('.' + element).find('.container-custom.more-info-container').offset().top-((self.parents('.swiper-slide').parents('.swiper-wrapper').height())/2)-self.parents('.swiper-slide').closest('.' + element).find('.container-lg').height()},10);
		//$("html, body").scrollTop($(element).offset().top);

		/*$('html,body').animate({

			//scrollTop: moreInfoPosition-swiperHeight-headingContainerHeight


		},10);*/

	}
	else if (self.parents('.swiper-slide').hasClass('active')) {
		self.parents('.swiper-slide').removeClass('active');
		self.parents('.swiper-slide').closest('.' + element).find('.swiper-custom-pagination-desktop').removeClass('new-pos');
		self.parents('.swiper-slide').closest('.' + element).find('.swiper-custom-pagination-desktop div[class^=swiper-button-]').removeClass('new-pos');
		self.parents('.swiper-slide').closest('.' + element).find('.container-custom.more-info-container').hide();
		/*$('html,body').animate({
			scrollTop: self.parents('.swiper-slide').closest('.' + element).offset().top-((self.parents('.swiper-slide').parents('.swiper-wrapper').height())/2)+
			self.parents('.swiper-slide').closest('.' + element).find('.container-lg').height()
			},'fast');*/
	}


}

var swiper;
function swiperCarousel(){
	$(document).find('.swiper-container.aswiper-two').each(function (index, element) {
		var $this = $(this);
		swiper = new Swiper($this, {
			pagination: $this.parents('section.box-bg-grey').find('.swiper-pagination'),
			nextButton: $this.parents('section.box-bg-grey').find('.swiper-button-next'),
			prevButton: $this.parents('section.box-bg-grey').find('.swiper-button-prev'),
			slidesPerView: 4,
			centeredSlides: false,
			slidesOffsetBefore:60,
			slidesOffsetAfter:340,
			paginationType: 'custom',
			paginationClickable: $this.parents('section.box-bg-grey').find('.swiper-pagination'),
			observer: false,
			spaceBetween: 15,
			grabCursor: true,
			resizeReInit: true,
			initialSlide: 0,
			
			

			onSlideChangeStart: function (swiper) {
			
				$this.find('.swiper-custom-pagination-desktop').removeClass('new-pos');
				$this.find('.swiper-custom-pagination-desktop div[class^=swiper-button-]').removeClass('new-pos');
				$this.parents('section.box-bg-grey').find('.container-custom.more-info-container').hide();
				$this.find('.swiper-slide.active').removeClass('active');
				
				if ($(window).width() > 991) {
				
					$this.find('.swiper-custom-pagination-desktop div[class^=swiper-button-next]').css('right','0.75%');
					//$this.find('.swiper-wrapper').css('padding-left','60px');
					$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
					/*if ($this.find('.swiper-slide-active').index() == 1) {

						setTimeout(function () {
							
							$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
							$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
						
							
						}, 0);
					} else if ($this.find('.swiper-slide-active').index() == 2) {

						setTimeout(function () {

							$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
							$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
							
						}, 0);

					}*/
					if ($this.find('.swiper-slide-active').index() > 0) {
						setTimeout(function () {

							$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
							$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
							$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
							
							if ($this.find('.swiper-slide-active').index() == ($this.find('.swiper-slide').length - 4)) {
								$this.find('.swiper-button-next').show();
								if(swiper.params.slidesOffsetAfter==340){
									
									swiper.params.slidesOffsetAfter=360;
									if ($(window).width() >= 1600) {
									
										swiper.params.slidesOffsetAfter=400;
									}
									swiper.update();
								}
							
							}
							
							else if ($this.find('.swiper-slide-active').index() == ($this.find('.swiper-slide').length - 3)) {
								$this.find('.swiper-button-next').hide();

								swiper.params.slidesOffsetAfter=287;

								if ($(window).width() >= 1380) {
										swiper.params.slidesOffsetAfter=315;

								}
								swiper.update();
							}
							else {
								$this.find('.swiper-button-next').show();
								if($this.find('.swiper-slide').length <= 3){
									$('.swiper-slide-active,.swiper-slide-next,.swiper-slide-prev').css({"opacity":"1","pointer-events":"auto"});
									$this.find('.swiper-button-next,.swiper-button-prev').hide();
									swiper.setWrapperTranslate(60, 0, 0);
									swiper.params.slidesOffsetBefore= 60;
									swiper.params.slidesOffsetAfter= 0;
									swiper.update();
								}
							}

						}, 0);


					}
					else if ($this.find('.swiper-slide-active').index() == 0) {
				
						$this.find('.swiper-custom-pagination-desktop div[class^=swiper-button-next]').css('right','4.75%');
						setTimeout(function () {
								$this.find('.swiper-button-next').show();
								if($this.find('.swiper-slide').length <= 3){
									$this.find('.swiper-button-next,.swiper-button-prev').hide();
									swiper.setWrapperTranslate(60, 0, 0);
									swiper.params.slidesOffsetBefore= 60;
									swiper.params.slidesOffsetAfter= -60;
									swiper.update();
								}
								
								$('.swiper-slide-active,.swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
								
								$this.find('.swiper-wrapper').css('padding-left','0');
								swiper.setWrapperTranslate(60, 0, 0);
							
								if (window.matchMedia('(min-width:769px) and (max-width: 1024px) and (orientation:landscape)').matches){
								//console.log('sa..');
								//setTimeout(function () {
									swiper.setWrapperTranslate(30, 0, 0);
								//},0);
								}
							
							}, 10);
							
							
						

					}


				}
				
			},
	
	
		
			breakpoints: {
				1440:{
					slidesPerView: 4,
					spaceBetween: 15,
					centeredSlides: false,
					slidesOffsetAfter:360,
					slidesOffsetBefore : 60
				},
				1024: {
					slidesPerView: 4,
					spaceBetween: 15,
					centeredSlides: false,
					slidesOffsetAfter:360,
					slidesOffsetBefore : 30,
					onAfterResize:function(swiper){
						//setTimeout(function(){
						
					 if(window.matchMedia('(min-width:1024px) and (max-width:1366px) and (orientation:portrait)').matches)
						if ($this.find('.swiper-slide-active').index() == 0) {
							swiper.setWrapperTranslate(60, 0, 0);
							swiper.params.slidesOffsetBefore = 60;
							swiper.update();
						}
						//},0);
					}
				},
				991: {
					slidesPerView: 2,
					spaceBetween: 15,
					centeredSlides: false,
					slidesOffsetBefore:0,
					slidesOffsetAfter: 0,
					paginationCustomRender: function (swiper, current, total) {
						if (current.toString().length == 1 && current == '9') {
                          //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          if((swiper.slides.length).toString().length == 1){
							
							$this.parents('section.box-bg-grey').find('.swiper-pagination').html('0' + current + '-' + (current + 1) + '<span class="pagination-seperator">/</span>' + '0' + swiper.slides.length);
                            //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          }
                          else if((swiper.slides.length).toString().length >= 2){
                            //return '0' + current + '-' + (current + 1) + '/' + swiper.slides.length;
							 $this.parents('section.box-bg-grey').find('.swiper-pagination').html('0' + current + '-' + (current + 1) + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
                          }
                        } 

						else if (current.toString().length == 1) {
						  if((swiper.slides.length).toString().length  == 1){
							//return '0' + current + '-' + '0' + (current + 1) + '/'+'0' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination').html('0' + current + '-' + '0' + (current + 1) + '<span class="pagination-seperator">/</span>' +'0' + swiper.slides.length);
						  }
						  else if((swiper.slides.length).toString().length  >= 2){
							
							
							//return '0' + current + '-' + '0' + (current + 1) + '/' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current + '-' + '0' + (current + 1) + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
						  }
						}
						else if (current.toString().length >= 2) {
							
							
							//return current + '-' + (current + 1) + '/'+ swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html(current + '-' + (current + 1) + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
						}

					}
				},
				767: {
					slidesPerView: 1,
					spaceBetween: 30,
					centeredSlides: true,
					slidesOffsetAfter: 0,
					slidesOffsetBefore:0,
					paginationCustomRender: function (swiper, current, total) {
						if (current.toString().length == 1 && current == '9') {

                            //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          if((swiper.slides.length).toString().length == 1){
                            //return '0' + current  + '/' + '0' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current  + '<span class="pagination-seperator">/</span>' + '0' + swiper.slides.length);
							
                          }
                          else if((swiper.slides.length).toString().length >= 2){
                           // return '0' + current + '/' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
                          }
                        } else if (current.toString().length == 1) {



                            //return '0' + current + '-' + '0' + (current + 1) + '/' + '0' + swiper.slides.length;
                            if((swiper.slides.length).toString().length == 1){
                               // return '0' + current + '/' + '0' + swiper.slides.length;
								$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + '0' + swiper.slides.length);
                              }
                              else if((swiper.slides.length).toString().length >= 2){
                               // return '0' + current + '/' + swiper.slides.length;
								$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
                              }
                        } else if (current.toString().length >= 2) {
                            //return current  + '/' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html(current  + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
                        }

					  }
					
				},
				320: {
					slidesPerView: 1,
					spaceBetween: 30,
					centeredSlides: true,
					slidesOffsetAfter: 0,
					slidesOffsetBefore:0,
					paginationCustomRender: function (swiper, current, total) {
						if (current.toString().length == 1 && current == '9') {

                            //return '0' + current + '-' + (current + 1) + '/' + '0' + swiper.slides.length;
                          if((swiper.slides.length).toString().length == 1){
                            //return '0' + current  + '/' + '0' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current  + '<span class="pagination-seperator">/</span>' + '0' + swiper.slides.length);
							
                          }
                          else if((swiper.slides.length).toString().length >= 2){
                           // return '0' + current + '/' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
                          }
                        } else if (current.toString().length == 1) {



                            //return '0' + current + '-' + '0' + (current + 1) + '/' + '0' + swiper.slides.length;
                            if((swiper.slides.length).toString().length == 1){
                               // return '0' + current + '/' + '0' + swiper.slides.length;
								$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + '0' + swiper.slides.length);
                              }
                              else if((swiper.slides.length).toString().length >= 2){
                               // return '0' + current + '/' + swiper.slides.length;
								$this.parents('section.box-bg-grey').find('.swiper-pagination ').html('0' + current + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
                              }
                        } else if (current.toString().length >= 2) {
                            //return current  + '/' + swiper.slides.length;
							$this.parents('section.box-bg-grey').find('.swiper-pagination ').html(current  + '<span class="pagination-seperator">/</span>' + swiper.slides.length);
                        }


					}
				}
			}
		});
		
	
		$(window).resize(function () {
		
		  if(!( /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) ) {

			if ((window.outerHeight - window.innerHeight) > 100 || (!((window.outerHeight - window.innerHeight) > 100) && !(window.outerHeight - window.innerHeight) == 0)) {

				/*if ($this.find('.swiper-slide-active').index() == 1) {
					setTimeout(function () {
						swiper.setWrapperTranslate(-341, 0, 0);
					}, 0);

				}*/
				if ($this.find('.swiper-slide-active').index() == 0) {
					setTimeout(function () {
						$this.find('.swiper-wrapper').css('padding-left','0');
						swiper.setWrapperTranslate(60, 0, 0);
						
					}, 0);

				}
			}
		  }
		  else if(( /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) ) {
		       /*if (window.matchMedia('(min-width:320px) and (max-width:768px)').matches){
							console.log('320');
							$this.find('.swiper-wrapper').css('padding-left','0');
							setTimeout(function () {
								if ($this.find('.swiper-slide-active').index() == 0) {
									$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
									swiper.setWrapperTranslate(0, 0, 0);
								}
							},0);
				}
				else */
				$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
				if (window.matchMedia('(min-width:768px) and (max-width:769px) and (orientation:portrait)').matches){
							$this.find('.swiper-wrapper').css('padding-left','0');
							setTimeout(function () {
								if ($this.find('.swiper-slide-active').index() == 0) {
									swiper.setWrapperTranslate(0, 0, 0);
								
								}
							},0);
				}
				else if (window.matchMedia('(min-width:769px) and (max-width: 1024px) and (orientation:landscape)').matches){
						//console.log('sa..');
						//$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
						setTimeout(function () {
							if ($this.find('.swiper-slide-active').index() == 0) {
								swiper.setWrapperTranslate(30, 0, 0);
								
								$this.find('.swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
								//$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
							}
							else{
								$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
								$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
								$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
								$this.find('.swiper-wrapper').css('padding-left','60px');
							}
						},0);
				}
				else if(window.matchMedia('(min-width: 1024px) and (max-width:1366px) and (orientation:portrait)').matches){
					console.log('1366--');
					//$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
					setTimeout(function () {
					 if ($this.find('.swiper-slide-active').index() == 0) {
						//console.log('1366--1');
						
						swiper.setWrapperTranslate(60, 0, 0);
					
						//$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
					 }
					 else{
					 	
						//console.log('1366--1 else');
						$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
						$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
						$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
						$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
						$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
						$this.find('.swiper-wrapper').css('padding-left','60px');
					
					 }
					},0);
			  }
			  else if(window.matchMedia('(min-width: 1024px) and (max-width:1366px) and (orientation:landscape)').matches){
					//console.log('kksad 1366 landscape');
					
					setTimeout(function () {
					//$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
					 if ($this.find('.swiper-slide-active').index() == 0) {
						swiper.setWrapperTranslate(60, 0, 0);
						//$this.find('.swiper-slide-active').css({"opacity":"1","pointer-events":"auto"});
					 }
					 else{
						$(' .swiper-slide-prev').prev().css({"opacity":"1","pointer-events":"auto"});
						$(' .swiper-slide-prev').css({"opacity":"0.25","pointer-events":"none"});
						$(' .swiper-slide-next').css({"opacity":"1","pointer-events":"auto"});
						$(' .swiper-slide-next').next().css({"opacity":"1","pointer-events":"auto"});
						$(' .swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
						$this.find('.swiper-wrapper').css('padding-left','60px');
						
					 }
				},0);
			  }
		 }
		 
		 
		});
		
		if ($(window).width() > 991) {
			if ($this.find('.swiper-slide').length <= 3) {

				$this.find('.swiper-button-next').hide();
			}
			else if ($this.find('.swiper-slide').length > 3) {
				$this.find('.swiper-button-next').show();
			}
			$this.find('.swiper-slide-next').next().next().css({"opacity":"0.25","pointer-events":"none"});
			swiper.setWrapperTranslate(60, 0, 0);

			if( /Android|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
					
					if (window.matchMedia('(min-width:769px) and (max-width: 1024px) and (orientation:landscape)').matches){
							//console.log('sa..onload');
							//setTimeout(function () {
								swiper.setWrapperTranslate(30, 0, 0);

								
							//},0);
				}
				 else if(window.matchMedia('(min-width: 1024px) and (max-width:1366px)').matches){
					
					swiper.params.slidesOffsetBefore = 60;
					swiper.update();
				 }
				
			
			}
		}
	
	});


}
