$(document).ready(function() {
	$("#auto-suggestion_listbox").addClass("autosuggestions-custom");
  /*=====kendo autosuggestion======*/ 
  $("#autocomplete").kendoAutoComplete({
		minLength: 1,
		filter: "startswith",
		autoWidth: true,
		dataSource:autosuggestion_data,
		template: $.proxy(kendo.template("#= formatValue(data, this.val()) #"), $("#autocomplete")),
	});
	$("#autocomplete-mb").kendoAutoComplete({
		minLength: 1,
		filter: "startswith",
		autoWidth: true,
		dataSource: autosuggestion_data,
		template: $.proxy(kendo.template("#= formatValue(data, this.val()) #"), $("#autocomplete-mb")),
	});
    /*=====kendo autosuggestion======*/ 
    $("#active-watchlist-dd").kendoDropDownList({
		dataTextField: "title",
		dataValueField: "title",
		filter: "startswith",
		dataSource: wl_active,
		valueTemplate:'<div>'+
                  '<div class="wl-active">Active Watchlist</div>'+
                  '<div class="watchlist-value">'+
                  '<div class="wl-value-ellipsis">#: data.title #</div>'+
                  '<span class="counter">(#: data.list #)</span></div></div>', 
		template:'<a href="javascript:void(0)" class="wl-text"><div class="wl-activecounter-block"><div class="wlcounter-left-wrap"><div class="visible-lg-inline-block visible-md-inline-block wl-ellipsis active-wl-text">#: data.title #</div></div><div class="visible-lg-inline-block visible-md-inline-block float-right active-wl-counter">(#: data.list #)</div></div></a>',
		dataBound:function(){
			var activeWatchlist = $("#active-watchlist-dd").data("kendoDropDownList");
			var len =activeWatchlist.dataSource.data().length;
			if(len<6){
				$(".k-list-filter").css("display","none");
			}
			else{
				$(".k-list-filter").css("display","block");
			}
		}
	});
	/*==Scripetd Details Dropdowns==*/
	$("#version-dropdown").kendoDropDownList({
		dataTextField: "trailerVersion",
		dataValueField: "trailerVersion",
		dataSource: version_data,
		valueTemplate:'<span><span class="labelname-dd">Version:</span><span class="labeltext-dd">#: data.trailerVersion #</span></span>',		
	});
	$("#season-dropdown").kendoDropDownList({
		dataTextField: "seasonNumber",
		dataValueField: "seasonNumber",
		dataSource: seasons_data,
		valueTemplate:'<span><span class="labelname-dd">#: data.seasonNumber #:</span><span class="labeltext-dd">#: data.seasonEpisodes # Episodes</span></span>',		
	});
	$("#format-selector").kendoDropDownList({
		dataTextField: "formatCut",
		dataValueField: "formatCut",
		dataSource: seriesFormat_data,
	});

	/*==Marketing Collateral Cascading Dropdwons ==*/
	var mcSeason = $("#mc-season").kendoDropDownList({
		dataTextField: "season",
		dataValueField: "season",
		dataSource: mc_season_data,
		valueTemplate: '<span><span class="labelname-dd">Season:</span><span class="labeltext-dd">#: data.season #</span></span>',   
		
	}).data("kendoDropDownList");

	var mcEpisodes = $("#mc-episode").kendoDropDownList({
		autoBind: false,
		cascadeFrom: "mcSeason",
		dataTextField: "episode",
		dataValueField: "episode",
		dataSource: mc_episode_data,
		//enable: false,
		valueTemplate: '<span><span class="labelname-dd">Episode:</span><span class="labeltext-dd">#: data.episode #</span></span>',   
	}).data("kendoDropDownList");

	var mcFilter = $("#mc-type").kendoDropDownList({
		autoBind: false,
		cascadeFrom: "mcEpisodes",
		dataTextField: "type",
		dataValueField: "type",
		dataSource: mc_type_data,
		valueTemplate: '<span><span class="labelname-dd">Type:</span><span class="labeltext-dd">#: data.type #</span></span>',   
	}).data("kendoDropDownList");

	/*=====movies-listing dropdowns====*/ 
	$("#sub-category").kendoDropDownList({
    	dataSource:listing_subcategory_data,
  dataTextField: "subcategory",
  dataValueField: "subcategory",
  valueTemplate: '<span><span class="labelname-dd">Sub-Category:</span><span class="labeltext-dd">#: data.subcategory #</span></span>',   
});
	$("#category").kendoDropDownList({
    	dataSource:listing_category_data,
  dataTextField: "category",
  dataValueField: "category",
  valueTemplate: '<span><span class="labelname-dd">Category:</span><span class="labeltext-dd">#: data.category #</span></span>',   
});
	$("#genre").kendoDropDownList({
    	dataSource:listing_genre_data,
  dataTextField: "genre",
  dataValueField: "genre",
  valueTemplate: '<span><span class="labelname-dd">Genre:</span><span class="labeltext-dd">#: data.genre #</span></span>',   
});
$("#sortby").kendoDropDownList({
    	dataSource:listing_sortby_data,
  dataTextField: "sortby",
  dataValueField: "sortby",
  valueTemplate: '<span><span class="labelname-dd">Sort By:</span><span class="labeltext-dd">#: data.sortby #</span></span>',   
});

/*====search results dropdown====*/
$("#programtype-dd").kendoDropDownList({
	dataSource:programtypedd_data,
  dataTextField: "genre",
  dataValueField: "genre",
	valueTemplate: '<span><span class="labelname-dd">Program Type:</span><span class="labeltext-dd">#:data.genre#</span></span>', 
	
});
$("#searchresults-dd").kendoDropDownList({
	dataSource:searchdd_data,
  dataTextField: "searchsort",
  dataValueField: "searchsort",
  valueTemplate: '<span><span class="labelname-dd">Sort Results:</span><span class="labeltext-dd">#: data.searchsort #</span></span>',   
});
// $("#datefilterone-dd").kendoDatePicker();
// $("#datefiltertwo-dd").kendoDatePicker();
$("#datefilterone-dd").kendoDatePicker({
	// dataSource:dateone_data,
   dataTextField: "date",
  dataValueField: "date",
 	valueTemplate: '<span><span class="labelname-dd">From:</span><span class="labeltext-dd">#: data.date #</span></span>', 
});
$("#datefiltertwo-dd").kendoDatePicker({
	// dataSource:datetwo_data,
  // dataTextField: "date",
  // dataValueField: "date",
  // valueTemplate: '<span><span class="labelname-dd">From:</span><span class="labeltext-dd">#: data.date #</span></span>', 
});
$("#yearfilterone-dd").kendoDatePicker({
	start: "decade",
	//defines when the calendar should return date
	depth: "decade",
	dateInput: true,
	format:"yyyy"
	// dataSource:yearone_data,
  // dataTextField: "date",
  // dataValueField: "date",
  // valueTemplate: '<span><span class="labelname-dd">From:</span><span class="labeltext-dd">#: data.date #</span></span>', 
});
$("#yearfiltertwo-dd").kendoDatePicker({
	//defines the start view
        start: "decade",
        //defines when the calendar should return date
        depth: "decade",
				dateInput: true,
				format:"yyyy"
	// dataSource:yeartwo_data,
  // dataTextField: "date",
  // dataValueField: "date",
  // valueTemplate: '<span><span class="labelname-dd">From:</span><span class="labeltext-dd">#: data.date #</span></span>', 
});
$("#category-dd").kendoDropDownList({
	dataSource:category_data,
  dataTextField: "category",
  dataValueField: "category",
  valueTemplate: '<span><span class="labelname-dd">Category:</span><span class="labeltext-dd">#: data.category #</span></span>', 
});
$("#subcategory-dd").kendoDropDownList({
	dataSource:subcategory_data,
  dataTextField: "subcategory",
  dataValueField: "subcategory",
  valueTemplate: '<span><span class="labelname-dd">Sub-Category:</span><span class="labeltext-dd">#: data.subcategory #</span></span>', 
});
/*========search page autosuggestion====*/ 
	$("#auto-suggestion").kendoAutoComplete({
	minLength: 1,
	filter: "startswith",
	autoWidth: true,
	dataSource: inputauto_data,
	template: $.proxy(kendo.template("#= formatValue(data, this.val()) #"), $("#auto-suggestion")),
});
/*========search page autosuggestion====*/ 
/*====search results dropdown====*/
/*=====watchlist Dropdown=====*/
$("#watchlistsort-dd").kendoDropDownList({
	dataSource:watchlistsearchdd_data,
  dataTextField: "watchlistsearchsort",
  dataValueField: "watchlistsearchsort",
	valueTemplate: '<span><span class="labelname-dd">Sort Results:</span><span class="labeltext-dd">#: data.watchlistsearchsort #</span></span>',   
});
$("#watchlistname-dd").kendoDropDownList({
	dataTextField: "watchlistname",
	dataSource:watchlist_data
});
$("#auto-suggestion-wl").kendoAutoComplete({
		minLength: 1,
		filter: "startswith",
		autoWidth: true,
	dataSource: inputautowl_data,
		template: $.proxy(kendo.template("#= formatValue(data, this.val()) #"), $("#auto-suggestion-wl")),
});
$("#wl-episodes-dd").kendoDropDownList({
	dataSource:watchlistepisodedd_data,
  dataTextField: "watchlistepisodesort",
  dataValueField: "watchlistepisodesort",
	valueTemplate: '<span><span class="labelname-dd">Season 1:</span><span class="labeltext-dd">#: data.watchlistepisodesort #</span></span>',   
});

/*=====watchlist Dropdown=====*/
/*========contacts page dropdown===*/
$("#territory").kendoDropDownList({
	dataSource:territory_data,
  dataTextField: "territory",
  dataValueField: "territory",
  valueTemplate: '<span><span class="labelname-dd">Territory:</span><span class="labeltext-dd">#: data.territory #</span></span>', 
});
$("#department").kendoDropDownList({
	dataSource:department_data,
  dataTextField: "department",
  dataValueField: "department",
  valueTemplate: '<span><span class="labelname-dd">Department:</span><span class="labeltext-dd">#: data.department #</span></span>', 
});
$("#programtype-dd").change(function () {
	var selectedvalue = this.value;
	if(selectedvalue.trim()=="Movies"){
		$(".episodes-search-wrapper").addClass("overlay-section");
	}
	else{
		$(".episodes-search-wrapper").removeClass("overlay-section");
	}
	if(selectedvalue.trim()=="Movies" || selectedvalue.trim()=="Formats"|| selectedvalue.trim()=="All"){
		$("#advanced-btn").show();
	}
	else{
		$("#advanced-btn").hide();
	}
});
// if($("#programtype-dd").data("kendoDropDownList").value().trim()=="Movies"){
// 	debugger;

// }
});
