var wl_active=[
	{
		title:"WATCHLIST NAME LOREM",
		list:"12345",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET CONSECTETER",
		list:"21342324",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET",
		list:"31",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET CONSECTETER",
		list:"41",
	},
    {
		title:"WATCH LIST NAME LOREM",
		list:"51",
	},
	{
		title:"LOREM IPSUM DOLOR SIT AMET CONSECTETER",
		list:"61",
	}
    
];
var version_data=[
	{
		trailerVersion:"German"
	},
];
var seasons_data=[
	{
		seasonNumber:"Season 1",
		seasonEpisodes:"4"
	},
	{
		seasonNumber:"Season 2",
		seasonEpisodes:"2"
	},
	{
		seasonNumber:"Season 3",
		seasonEpisodes:"6"
	},
	
];
var seriesFormat_data=[
	{
		formatCut:"4x120'",
	},
	{
		formatCut:"3x90'",
	},
	{
		formatCut:"5x150'",
	},
	
];
var mc_season_data=[
	{
		season:"All",
	},
	{
		season:"1",
	},
	{
		season:"2",
	},
	{
		season:"3",
	}
];
var mc_episode_data=[
	{
		episode:"All",
	},
	{
		episode:"001 – Episode Title",
	},
	{
		episode:"002 – Episode Title",
	},
	{
		episode:"003 – Episode Title",
	},
	{
		episode:"004 – Episode Title",
	},
		{
		episode:"3",
	},
	{
		episode:"4",
	},
];
var mc_type_data=[
	{
		type:"All",
	},
	{
		type:"Chyron List",
	},
	{
		type:"Transcript",
	},
	{
		type:"Credits",
	},
		{
		type:"All",
	},
	{
		type:"Scripted",
	},
	{
		type:"Factual",
	},
	{
		type:"Movies",
	},
];
var programtypedd_data = [
	{
		genre:"All "
	},
{
	genre:"Scripted "
},
{
	genre:"Factual "
},
{
	genre:"Movies "
},
{
	genre:"Factual "
},
{
	genre:"Movies "
},
{
	genre:"Formats "
}
];
var searchdd_data=[
	{
		searchsort:"Release Date "
	},
	{
		searchsort:"Alphabetical by Series Name"
	},
];
var watchlistsearchdd_data=[
	{
		watchlistsearchsort:"Recently Added"
	},
	{
		watchlistsearchsort:"Alphabetical by Series Name"
	}
];
var dateone_data=[
	{
		date:"03/15/2012"
	},
	{
		date:"09/09/2014"
	},
	{
		date:"01/09/2014"
	},
];
var datetwo_data=[
	{
		date:"03/15/2012"
	},
	{
		date:"09/09/2014"
	},
	{
		date:"01/09/2014"
	},
	{
		date:"03/15/2012"
	},
	{
		date:"09/09/2014"
	},
	{
		date:"01/09/2014"
	}
];
var yearone_data=[
	{
		date:"2012"
	},
	{
		date:"2013"
	},
	{
		date:"2014"
	},
	{
		date:"2015"
	},
	{
		date:"2016"
	},
	{
		date:"2017"
	}
];
var yeartwo_data=[
	{
		date:"2017"
	},
	{
		date:"2016"
	},
	{
		date:"2015"
	},
	{
		date:"2014"
	},
	{
		date:"2013"
	},
	{
		date:"2012"
	}
];
var category_data=[
	{
		category:"Crime and Redemption"
	},
	{
		category:"Crime and Redemption"
	},
	{
		category:"Crime and Redemption"
	},
	{
		category:"Crime and Redemption"
	},
	{
		category:"Crime and Redemption"
	},
	{
		category:"Crime and Redemption"
	}

];
var subcategory_data=[
	{
	subcategory:"New  for #ntape"
	},
	{
		subcategory:"New  for #ntape"
	},
	{
	subcategory:"New  for #ntape"
	},
	{
		subcategory:"New  for #ntape"
	},
	{
	subcategory:"New  for #ntape"
	},
	{
		subcategory:"New  for #ntape"
	},
];
var inputauto_data=[
    "A who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn",
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn",
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
    "Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn"
];
var autosuggestion_data = [
    "A who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn",
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn",
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
    "Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn"
];
var listing_subcategory_data = [
	{
		subcategory:"Season"
	},
	{
		subcategory:"Crime and Redemption"
	},
	{
		subcategory:"Crime and Redemption"
	},
	{
		subcategory:"Crime and Redemption"
	},
];
var listing_category_data =[
		{
		category:"Crime and Redemption"
	},
	{
		category:"American original"
	},
	{
		category:"Baby Behind the bars"
	},
	{
		category:"America's Secret Warriors"
	},
	{
		category:"History and Science"
	},
	{
		category:"LifeStyle"
	},
];
var listing_genre_data =[
		{
		genre:"Crime and Redemption"
	},
	{
		genre:"American original"
	},
	{
		genre:"Baby Behind the bars"
	},
	{
		genre:"America's Secret Warriors"
	},
	{
		genre:"History and Science"
	},
	{
		genre:"LifeStyle"
	},
];
var listing_sortby_data =[
		{
		sortby:"Most Recently Released"
	},
	{
		sortby:"A-Z"
	},
];
var watchlist_data=[
	{

		watchlistname:"Watchlist Name Lorem"
	},
	{
		watchlistname:"Watchlist Name Ipsum"
	},
];
var watchlistepisodedd_data=[
	{

		watchlistepisodesort:"4 Episodes"
	},
	{
		watchlistepisodesort:"10 Episodes"
	},
	{
		watchlistepisodesort:"13 Episodes"
	},
	{
		watchlistepisodesort:"15 Episodes"
	}
];
var territory_data=[
	{
		territory:"All"
	},
	{
		territory:"Watchlist Name Ipsum"
	},
];
var department_data=[
	{
		department:"All"
	},
	{
		department:"Watchlist Name Ipsum"
	},
];
var inputautowl_data=[
    "A who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn",
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn",
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
    "Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn", 
	"Who KIlled mandjkdn"
];