
<html>
<head>
 <title>Site Title</title>
 <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
 <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

</head>
<body>

<div id="wrapper">
<div id="header">
<h1>SOUTH TOUR</h1>



<div class="futrmenu">
<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>

<a style="margin-left:1050px; color:black;" href="<?php echo wp_login_url( home_url() );?>">Login</a>


</div>

<?php wp_nav_menu(array(
	'menu' => 6, 
	'container_id' => 'cssmenu', 
	'walker' => new CSS_Menu_Walker()
)); ?>
<?php  include "slideshow.php"?>

</div>
