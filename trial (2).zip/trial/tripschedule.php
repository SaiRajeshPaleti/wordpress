<?php
/* Template Name: tripschedule */

?>
<form action="http://localhost:8012/wordpress/tripschedule.php" method="POST">

</form>
<?php
session_start();
    global $wpdb;
	

	global $current_user;
      get_currentuserinfo();
$user=$current_user->user_login;
    
	
	
	if(is_super_admin())
	{
	
	
	$result = $wpdb->get_results ( "SELECT * FROM tripdetails");
	?>
	<center>

<table border="1" style="background-color:E6E6FA; border-color:white;">
<tr style="background-color:FFF0F5;">
 <th>User Name</th>
 <th>place</th>
 <th>Date</th>
 <th>Package</th>
 <th>Number of Adults</th><th>Number Of Children</th><th>Contact Details</th><th>Total Bill</th>
</tr>
   
<?php
   foreach ( $result as $print )   
	{
    ?>
	
		<tr>
		<td><?php echo $print->user_name;
		?></td>
		
		
		<td><?php echo $print->place;?></td>
		
		
		<td><?php echo $print->dt;?></td>
		
		<td><?php echo $print->tourpackage;?></td>
		<td><?php echo $print->Number_of_adults;?></td>
		<td><?php echo $print->Number_of_children;?></td>
		<td><?php echo $print->bill;?></td>
		<td><?php echo $print->contact_number;?></td>
		</tr>
    <?php 
	}

}
else
{
echo $user;
echo "\n You are not an admin";
}


?>

  </table>
 </center>