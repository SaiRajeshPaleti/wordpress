<?php
/* Template Name: hotelbookingschedule */
?>
<?php
session_start();

$user=$_SESSION['user'];  
 $conn = mysql_connect("localhost","root","");
   mysql_select_db('training');
   if(!$conn ) {
      die('Could not connect: ' . mysql_error());
   }?>
<?php
if(is_super_admin())
{
  $selectSQL = 'SELECT * FROM `hotelbookings`';

  if( !( $selectRes = mysql_query( $selectSQL ) ) ){
    echo 'Retrieval of data from Database Failed - #'.mysql_errno().': '.mysql_error();
  }else{
    ?>
<table border="1" style="background-color:E6E6FA; border-color:white;">
  <thead>
    <tr style="background-color:FFF0F5;">
      <th>Name</th>
      <th>City</th>
      <th>Hotel</th>
      <th>Room Price</th>
	  <th>Date</th>
	  <th>Number Of Days</th>
	  <th>Number Of Rooms</th>
	  <th>Extra Persons</th>
	  <th>Total Bill</th>
    </tr>
  </thead>
  <tbody>
    <?php
      if( mysql_num_rows( $selectRes )==0 ){
        echo '<tr><td colspan="4">No Rows Returned</td></tr>';
      }else{
        while( $row = mysql_fetch_assoc( $selectRes ) ){
          echo "<tr><td>{$row['user_name']}</td><td>{$row['city']}</td><td>{$row['hotel']}</td><td>{$row['roomprice']}</td><td>{$row['date']}</td><td>{$row['num_days']}</td><td>{$row['num_rooms']}</td><td>{$row['extra_persons']}</td><td>{$row['bill']}</td></tr>\n";
        }
      }
    ?>
  </tbody>
</table>
    <?php
  }

}
else{ echo "You are not a admin";}

   mysql_close($conn);
?>
</table>
</center>