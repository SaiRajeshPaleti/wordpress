<html lang="en">
<head>


<style>
body {font-family:Arial, Helvetica, sans-serif; font-size:12px;}

.fadein { 
position:relative; width:700px; height:250px;
background: url("slideshow-bg.png") repeat-x scroll left top transparent;
padding: 10px;
 }
.fadein img { position:absolute;height:240px;width:1245px;left:10px;top:10px;}
</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>
$(function(){
	$('.fadein img:gt(0)').hide();
	setInterval(function(){$('.fadein :first-child').next('img').fadeIn().end().appendTo('.fadein');}, 1000);
});
</script>

</head>
<body>

<a href="http://localhost:8012\wordpress\welcome\">
<div class="fadein">
<img src="http://localhost:8012\wordpress\wp-content\themes\trial\images\a.jpg">
<img src="http://localhost:8012\wordpress\wp-content\themes\trial\images\k.jpg">
<img src="http://localhost:8012\wordpress\wp-content\themes\trial\images\f.jpg">
<img src="http://localhost:8012\wordpress\wp-content\themes\trial\images\t.jpg">
<img src="http://localhost:8012\wordpress\wp-content\themes\trial\images\r.jpg">
<img src="http://localhost:8012\wordpress\wp-content\themes\trial\images\x.jpg">
</div>
</a>



<?php ///while(have_posts()):the_post()?>



<?php //if( has_post_thumbnail()) : ?>

<!--
   <a href="<?php //the_permalink(); ?>" title="<?php //the_title_attribute(); ?>" > </a>
  <a href="<?php //the_permalink(); ?>"> <?php //the_post_thumbnail(); ?></a>
   
  
 <?php //endif; ?> 
		<?php //endwhile;?>
</div>
<!--https://www.intechgrity.com/getting-post-thumbnail-on-wordpress-3-w-wo-specific-post-id/ -->


</body>
</html>