<?php
/* Template Name: index */
?>
<?php get_header(); ?>

<?php 

 get_sidebar();?>

<div id="main">
<div id="content">

<h1></h1>


<?php if (have_posts()) : while (have_posts()) : the_post();   ?>

<h1><?php the_title(); ?></h1>
<?php if ( has_post_thumbnail() ){
the_post_thumbnail('thumbnail');}?>
<h4>Posted on <?php the_time('jS M, l Y') ?></h4>

<p><?php the_content(__('(more...)')); ?></p>



 <?php endwhile; else: ?>
<?php endif; ?> 



<p></br>
<?php 
//include_once "register.php";
?>
</br>


<?php 
//nclude_once "ahotel.php";
?>

<?php

//include "stateselect.php";

?>

<?php 
//include "tamilnaduselect.php";
?>

<?php 
//include "karnatakaselect.php";
?>

<?php 

//include "andhraselect.php";
?>

<?php 

 //include_once "ap.php";
?></br>

<?php 
//if(is_super_admin())
//{
//include_once "tripschedule.php";}
//else{
//echo "Only admin have rights to access Trip Schedule.....Thank You";
//}?>

</p>
<?php //endif; ?>





</div>
</div>
<div id="delimiter">
</div>







<?php get_footer(); ?>


