<?php
/* Template Name: plantour */

?>
<?php ?>
<html>
<body>
<form action="#" method="POST" target="_parent">
<center>
<h2 style="color:#088A85;">Select Tour Package.</h2>
<table style="background-color:#088A85; border-color:white;">
<tbody>
<tr style="background-color:FFF0F5;">
<td><input name="chooseon"  type="radio" value="Heritage" /><label>Heritage Tour</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseon" type="radio"  value="Araku" /><label for="tpty"> Araku Trip</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseon" type="radio"  value="Srikakulam" /><label for="bza">Srikakulam Trip</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseon" type="radio"  value="jagdhalpur" /><label for="rjy"> vizag-araku-jagdhalpur</label></td>
</tr>
<tr style="background-color:FFF0F5;"><td style="border:none;" colspan="2" align="center"><input  style="background-color:#04B4AE;" name="sub" type="submit" value="Submit" /></td></tr>
</table>
</center>
</body>
</html>


<?php

 
if(isset($_POST['sub']))
{

session_start();
global $r,$s,$t;
$dt=$_SESSION['date'];

$place=$_SESSION['plac'];


$user=$_SESSION['user'];
if(!empty($place)&&!empty($dt))
{
$package=mysql_escape_string($_POST['chooseon']);
$conn = mysql_connect("localhost","root","");
mysql_select_db('training');
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
 

  $query="select * from tripdetails where dt='$dt' and place='$place' and tourpackage='$package'";
  $result=mysql_query($query,$conn) or die(mysql_error());
   
   while($row = mysql_fetch_array($result)){
   $r=$row['place'];
   $s=$row['dt'];
   $t=$row['tourpackage'];
   }
  
  if($r!=($place) && $s!=($dt) && $t!=($package))
  {
  
   $sql = "INSERT INTO tripdetails(user_name,place,dt,tourpackage)VALUES('$user','$place','$dt','$package')";
  
   
   $retval = mysql_query( $sql, $conn );
   
 
   if(! $retval ) {
      die('Could not enter data: ' . mysql_error());
	 
   }
   
   

   
   
   
   
   
if (isset($_POST['sub'])) {
if(isset($_POST['chooseon'])){
echo $user;
echo " selected ".$place."\n"; 
echo "and \t". $package . "package " ;
echo " on \n" .$dt; //  Displaying Selected Value
}

}
}

else{
   echo "<h3><center>someone else has already booked to your destination on</center></h3>";
   echo $dt;
   }


}

else
{
echo "<h3><center>Enter trip details properly</center></h3>";
}
}

?>

