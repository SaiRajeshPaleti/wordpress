<?php
/* Template Name: ahotel */
?>
<html>
<form action="#" method="POST">
<table border="1" style="background-color:E6E6FA; border-color:white;">
<tr style="background-color:FFF0F5;">
<td><label>Enter State</label></td>
<td><input name="state" type="text" /></td>
</tr>

<tr style="background-color:FFF0F5;">
<td><label>Enter City</label></td><td><input name="city" type="text" /></td>
</tr>

<tr style="background-color:FFF0F5;"><td>
<label>Enter Hotel</label></td><td><input name="htl" type="text" /></td></tr>

<tr style="background-color:FFF0F5;border:none;"><td style="border:none;" colspan="2" align="center"><input style="background-color:E6E6FA;" name="sub" type="submit" value="Insert" /></td></tr>
</table></form>
</html>

<?php
  if(isset($_POST['sub'])){
   $conn = mysql_connect("localhost","root","");
   
   $state=$_POST['state'];
   $city=$_POST['city'];
   $hotel=$_POST['htl'];
  
   
   mysql_select_db('training');
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
   
   //$sql = "INSERT INTO login(name,email,user,password)VALUES('$name','$email','$user','$password')";
   if(!empty($state) && !empty($city) && !empty($hotel))
   {
   $sql = "INSERT INTO hotelmanage(state,city,hotel)VALUES('$state','$city','$hotel')";
      
   
   $retval = mysql_query( $sql, $conn );
   
 
   if(! $retval ) {
      die('Could not enter data: ' . mysql_error());
	  echo "<script type='text/javascript'>alert('hotel registration failed')</script>";
	  
   }
   else{
   echo "<script type='text/javascript'>alert('hotel registration complete')</script>";
    }
}
else{
echo "check once";
}

   mysql_close($conn);
   }
?>