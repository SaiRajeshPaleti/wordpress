<?php
/* Template Name: ap */
?>
<?php session_start();
global $line;

mysql_connect("localhost","root","");
mysql_select_db("training"); ?>
<html>

<body>
<form action="#" method="POST">
<center>
<h2 style="color:#088A85;">Select city to visit.</h2>
<table style="background-color:#088A85;border-color:white;">
<tbody>
<tr>
<td><input name="chooseone"  type="radio" value="Visakhapatanam"  id="checky" /><label style="color:white;"> Visakhapatanam </label></td>
</tr>

<tr>
<td><input name="chooseone" type="radio"  value="Tirupati" id="checky" /><label for="tpty" style="color:white;" > Tirupati</label></td>
</tr>
<tr>
<td><input name="chooseone" type="radio"  value="Vijayawada"  id="checky"/><label for="bza" style="color:white;"> Vijayawada</label></td>
</tr>
<tr>
<td><input name="chooseone" type="radio"  value="Rajamahendravaram" id="checky" /><label for="rjy" style="color:white;"> Rajamahendravaram</label></td>
</tr>
<tr>
<td><input name="chooseone" type="radio" id="checky" value="Srikalahasthi" /><label for="sk" style="color:white;"> Srikalahasthi</label></td>
</tr>

<tr><td>
<label style="color:white;"><b>Select Date</b></label>
<input name="txt2" type="date" /></td></tr></br>
<tr><td style="border:none;" colspan="2" align="center"><input  style="background-color:white;" name="tour" type="submit" value="Plan Your Tour" /></td></tr>


</tbody>
</table>



</center></form>
</body>
</html>

<?php


if(isset($_POST['tour']))
{
$place=mysql_escape_string($_POST['chooseone']);
$dt=mysql_escape_string($_POST['txt2']);
if(empty($place) || empty($dt))
{
echo "<script type='text/javascript'>alert('Enter details properly..');window.location.href = 'http://localhost:8012/wordpress/book-trip/'</script>";
}
else{


global $current_user;
      get_currentuserinfo();
$user=$current_user->user_login;
$_SESSION['user']=$user;

$_SESSION['date']=$dt;

$_SESSION['plac']=$place;

echo "<script type='text/javascript'>alert('Proceed to select package..');window.location.href = 'http://localhost:8012/wordpress/wp-content/themes/trial/plantour.php'</script>";



}
}






?>


