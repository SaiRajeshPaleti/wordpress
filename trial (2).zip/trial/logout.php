<html>
<a href="<?php echo wp_logout_url( home_url() ); ?>">Logout</a>
</html>