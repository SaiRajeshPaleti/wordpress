<html>
<a href="<?php echo wp_login_url( home_url() ); ?>">Login</a>
</html>