<?php
/* Template Name: kerala*/
?>
<?php session_start();
global $line;

mysql_connect("localhost","root","");
mysql_select_db("training"); ?>
<html>
<body>
<form action="#" method="POST">


<center>
<h2 style="color:#088A85;">Select city to visit.</h2>
<table style="background-color:#088A85; border-color:white;">
<tbody>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Munnar" /><label><b> Munnar</b></label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Komarakam" /><label><b>Komarakam</b></label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Kovalam" /><label><b>Kovalam</b></label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Trissur" /><label><b> Trisusur</b></label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Tiruvananthapuram" /><label><b>Tiruvananthapuram</b></label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Allepy" /><label><b>Allepy</b></label></td>
</tr><tr style="background-color:FFF0F5;"><td>
<label><b>Select Date</b></label>
<input name="txt2" type="date" /></td></tr></br>
<tr><td style="border:none;" colspan="2" align="center"><input  style="background-color:white;" name="tour" type="submit" value="Plan Your Tour" /></td></tr>


</tbody>
</table>



</center></form>
</body>
</html>

<?php


if(isset($_POST['tour']))
{
$place=mysql_escape_string($_POST['chooseone']);
$dt=mysql_escape_string($_POST['txt2']);
if(empty($place) || empty($dt))
{
echo "<script type='text/javascript'>alert('Enter details properly..');window.location.href = 'http://localhost:8012/wordpress/book-trip/'</script>";
}
else{


global $current_user;
      get_currentuserinfo();
$user=$current_user->user_login;
$_SESSION['user']=$user;

$_SESSION['date']=$dt;

$_SESSION['plac']=$place;

echo "<script type='text/javascript'>alert('Proceed to select package..');window.location.href = 'http://localhost:8012/wordpress/wp-content/themes/trial/plantour.php'</script>";



}
}






?>
