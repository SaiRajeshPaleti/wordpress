<?php
/* Template Name: billgenerate */
?>
<?php
session_start();

$user=$_SESSION['user'];   

  if(isset($_POST['book']))
  {
   
   $user=$_SESSION['user'];   
   $city=$_SESSION['city'];

   $hotel=$_SESSION['hotel'];
   $days=$_POST['days'];
   $date=$_POST['date'];
   $num_rooms=$_POST['rooms'];
   $extrapersons=$_POST['extrapersons'];
   $roomprice=$_POST['roomprice'];
   $total=$_POST['billamount'];
	
   
   $conn = mysql_connect("localhost","root","");
   mysql_select_db('training');
   if(!$conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
if(!empty($city) && !empty($hotel) && !empty($days) && !empty($date) && !empty($roomprice) && !empty($total))
  {
 
   
	//$sql="select * from wp_users where user_login='$user'";
	//$query=mysql_query($sql,$conn);
//	$row = mysql_fetch_array($query);
   
   
   
 // if($row['user_login']!=($user) && $row['user_email']!=($email) )
	//{
			$sql = "INSERT INTO hotelbookings(user_name,city,hotel,roomprice,date,num_days,num_rooms,extra_persons,bill)VALUES('$user','$city','$hotel','$roomprice','$date','$days','$num_rooms','$extrapersons','$total')";
      
   
			$retval = mysql_query( $sql, $conn );
 
			if(! $retval ) 
				{
					die('Could not enter data: ' . mysql_error());
				}
				else
				{
				
					echo "<script type='text/javascript'>alert('Hotel Booking complete.......'); </script>";	 
				}   
	//}
	 //else
	 //{
   
		//$sql = "INSERT INTO login(name,email,user,password)VALUES('$name','$email','$user','$password')";
		//echo "<script type='text/javascript'>alert('user already exists..');window.location.href = 'register'</script>";
	  //}
	 
	}	 
	else
	{
		echo "<script type='text/javascript'>alert('Enter all fields properly....'); window.location.href = 'http://localhost:8012/wordpress/'</script>";
	}
  
 



   
?>
<?php
  $selectSQL = "SELECT * FROM `hotelbookings` WHERE `user_name`='$user' and `hotel`='$hotel'";

  if( !( $selectRes = mysql_query( $selectSQL ) ) ){
    echo 'Retrieval of data from Database Failed - #'.mysql_errno().': '.mysql_error();
  }else{?>
 <div class="table">   
<table border="1" style="background-color:E6E6FA; border-color:white;">
  <thead>
    <tr style="background-color:FFF0F5;">
      <th>Name</th>
      <th>City</th>
      <th>Hotel</th>
      <th>Room Price</th>
	  <th>Date</th>
	  <th>Number Of Days</th>
	  <th>Number Of Rooms</th>
	  <th>Extra Persons</th>
	  <th>Total Bill</th>
    </tr>
  </thead>
  <tbody>
    <?php
      if( mysql_num_rows( $selectRes )==0 ){
        echo '<tr><td colspan="4">No Rows Returned</td></tr>';
      }else{
        while( $row = mysql_fetch_assoc( $selectRes ) ){
          echo "<tr><td>{$row['user_name']}</td><td>{$row['city']}</td><td>{$row['hotel']}</td><td>{$row['roomprice']}</td><td>{$row['date']}</td><td>{$row['num_days']}</td><td>{$row['num_rooms']}</td><td>{$row['extra_persons']}</td><td>{$row['bill']}</td></tr>\n";
        }
      }
    ?>
  </tbody>
</table>
</div>
    <?php
  }

}
   mysql_close($conn);
?>
</table>
</center>