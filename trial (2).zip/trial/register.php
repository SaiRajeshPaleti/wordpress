<?php
/* Template Name: register */
?>
<table border='2' >
 <form action="#" method="POST">
 <tr><td>
<label>User Name:</td><td><input type="textbox" name="txt1" /></td>
<tr><td>
<label>Password:</td><td><input type="password" name="txt2"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"/></td>
<tr><td>
<label>FULL NAME</label></td><td><input type="textbox" name="txt3"/></td>
<tr><td><label>Email<label/></td><td><input type="email" name="txt4"/></td>
<tr><td><input type="submit" value="Submit" name="btn"/></td>
<td><input type="Reset" value="Reset" name="btn"/></td></tr>
</label></label></form>
</table>
<?php


global $u,$p,$e,$r;
  if(isset($_POST['btn']))
  {
   
   $conn = mysql_connect("localhost","root","");
   
   $user=$_POST['txt1'];
   $password=$_POST['txt2'];
   $name=$_POST['txt3'];
   $email=$_POST['txt4'];
	$pwd=wp_hash_password($password);
   
   
   mysql_select_db('training');
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
if(!empty($user) && !empty($password) && !empty($name) && !empty($email))
   {
 
   
	$sql="select * from wp_users where user_login='$user'";
	$query=mysql_query($sql,$conn);
	$row = mysql_fetch_array($query);
   
   
   
  if($row['user_login']!=($user) && $row['user_email']!=($email) )
	{
			$sql = "INSERT INTO wp_users(user_login,user_pass,user_nicename,user_email)VALUES('$user','$pwd','$name','$email')";
      
   
			$retval = mysql_query( $sql, $conn );
 
			if(! $retval ) 
				{
					die('Could not enter data: ' . mysql_error());
				}
				else
				{
					echo "<script type='text/javascript'>alert('registration complete'); window.location.href = 'http://localhost:8012/wordpress/wp-login.php?redirect_to=http%3A%2F%2Flocalhost%3A8012%2Fwordpress%2Fwp-admin%2F&reauth=1'</script>";	 
				}   
	}
	 else
	 {
   
		//$sql = "INSERT INTO login(name,email,user,password)VALUES('$name','$email','$user','$password')";
		echo "<script type='text/javascript'>alert('user already exists..');window.location.href = 'register'</script>";
	  }
	 
	}	 
	else
	{
		echo"fields should not be empty..Try again";
	}
  
 


   mysql_close($conn);
   }
?>