<div id="sidebar">

<a href="http://localhost:8012/wordpress/welcome/"><marquee>have a nice visit...</marquee></a>
<h2 ><?php _e('Categories'); ?></h2>
<ul >
 <?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?>
 
  <?php
 if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif; ?>

 
 
 
</ul>
<h2 ><?php _e('Archives'); ?></h2>
<ul >
 <?php wp_get_archives('type=yearly'); ?>
</ul>


</div>




<table border="2"><tr>
<?php
global $i;

if (have_posts() ) 
{ $i=0;
    while(have_posts()) 
	{ 					
         the_post();?>
				
				
				
				
		<?php		
        if ( has_post_thumbnail() ){
		
		 
            
		?>
			<?php
				if($i==0):
				
				?>
				
				
			
				 <?php set_post_thumbnail_size( 300, 300 );?>
				<td><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" ><?php the_title_attribute(); ?> </a></td>
  <td><a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail(); ?></a></td></tr>
				
		
				<?php $i++;
				
				?>
		
		
		<?php
			else:
		?>
		
		
		
<tr>	
	
	<?php set_post_thumbnail_size( 300, 300 ); ?>
 <td> <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail(); ?></a></td>
	<td><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" > <?php the_title_attribute(); ?></a></td></tr>		
			
        <?php 
		$i--;
		endif;
    }
		?>
		 <?php //the_content();?>
		
		
    <?php 
	}   
 }
   
?>
</table>










