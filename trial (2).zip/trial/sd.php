<html>
<head>
<link rel="stylesheet" href="path/to/bxslider/jquery.bxslider.css" /></head>
<script type='text/javascript' src='path/to/js/bxslider/jquery.bxslider.js'></script>
<script>
jQuery(document).ready(function() {
jQuery('.bxslider').bxSlider({
  adaptiveHeight: true,
  mode: 'horizontal',
  captions: true,
  auto: true,
  useCSS: true,
  easing: 'ease-in',
  pager: false
});
});
</script>
<?php
$content = '<ul class="bxslider">';
$loop = new WP_Query( array( 'post_type' => 'your_post_type', 'posts_per_page' => 10, 'post_status' => 'publish', 'orderby' => 'date', 'order' => 'DESC' ) );
	while ( $loop->have_posts() ) : $loop->the_post();
	if(has_post_thumbnail()){
		$thumb_id = get_post_thumbnail_id();
		$thumb_url = wp_get_attachment_image_src($thumb_id,'full', true);
		$content .= '<li><a href="';
		$content .= get_permalink();
		$content .= '"><img src="';
		$content .= $thumb_url&#91;0&#93;;
		$content .= '" alt="';
		$content .= get_the_title();
		$content .= '" /></a></li>';
		}
	endwhile;
$content .= '</ul>';
echo $content;
?>
</html>