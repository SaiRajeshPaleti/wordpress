<?php
/* Template Name: tamilnaduselect */
?>


<!-- City Select -->
<?php


session_start();

global $line;

mysql_connect("localhost","root","");
mysql_select_db("training");
global $x;

global $current_user;
      get_currentuserinfo();
$user=$current_user->user_login;
    $_SESSION['user']=$user;
	$u=$_SESSION['user'];


//query
$query ="SELECT distinct city FROM hotelmanage where state='tamilnadu'";
 $result = mysql_query($query); 


?><html>
<head>
</head>
<form action="#" method="POST">


      <select  name="city" >
	   <option> <?php echo "SELECT";?>

  </option> 
      <?php while ($line = mysql_fetch_array($result)){ ?> 


	  
      <option value="<?php echo $line['city'];?>"> <?php echo $line['city'];?>

  </option>   <?php } ?> </select>
  
<input type="submit" name="subsel" value="Select Hotel"/>
<!--End Of City Select-->


<!--Hotel Drop down-->
<?php

if(isset($_POST['subsel']))
{

$_SESSION['city']=$_POST['city'];
$R=$_SESSION['city'];

$query ="SELECT distinct hotel FROM hotelmanage where city='$R'";
 $result = mysql_query($query); 
?>


      <select  name="hotel" >
	  <option> <?php echo "SELECT";?>

  </option> 
	  
      <?php while ($line = mysql_fetch_array($result)){ ?> 

      <option value="<?php echo $line['hotel'];?>"> <?php echo $line['hotel'];?>

  </option>   <?php } ?> </select><?php } ?><input type="submit" name="sub2" value="Submit"/>
 
  </br>
  </form>
  <!--End Of HOtel Drop Down-->
  
  <!--Retrieving No Of Rooms and Hotel Price-->
  
  
  <?php
  if(isset($_POST['sub2']))
  {
  $_SESSION['hotel']=$_POST['hotel'];
  $t=$_SESSION['hotel'];
  $conn = mysql_connect("localhost","root","");
  mysql_select_db('training');
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
  
   $sql="select rooms,price from hotelmanage where hotel='$t'";
	$query=mysql_query($sql,$conn);
	$row = mysql_fetch_array($query);
	 $count=$row['rooms'] ;
	 $price=$row['price'];
	 $x=1;
	 
	 ?>
     
<!--End oF Retrieving-->	  
	  
	  <!--Hotel Booking Form-->
	  
	  <form action="http://localhost:8012/wordpress/wp-content/themes/trial/billgenerate.php" method="POST">
	  <h4><?php $r; ?></h4></br>
 <label>Number of Rooms</label>  <select  name="rooms" id="rm" onkeyup="sum();">
	  <option> <?php echo "SELECT";?>

  </option> 
  


<?php

$city=$_POST['city'];
$hotel=$_POST['hotel'];
echo $city;
?>
  
  
  
  <?php while ($x<=$count){ ?> 

      <option value="<?php echo $x;?>"> <?php echo $x;?>
  </option>   <?php $x++;} ?> </select>  <br>
  
  
  
<label>Number of Days</label><input type="textbox" name="days" id="txt1"  onkeyup="sum();" /><br>
<label>Date of Booking</label><input type="date" name="date"/></br>
<label>Number of extra persons per room</label><input type="textbox" id="ep" name="extrapersons" onkeyup="sum();"/><label>(Note:maximum 3 extra persons are allowed.350 per person)</label><br>
<label>Hotel Price Per Room</label><input type="text" id="price" name="roomprice" value="<?php echo $price;?>" onkeyup="sum();"/></br>
 
<label>Total Amount to be paid</label><input type="text" id="tmp" name="billamount"/></br>
<input type="submit" name="book" value="Book Now" />
<?php } ?>
 
</form>
 <!-- End of Hotel Booking Form-->
 
 <!--Dynamic Bill Generation-->
<script type="text/javascript">
function sum() {

		var txtNumberValue = document.getElementById('rm').value;
       var txtFirstNumberValue = document.getElementById('txt1').value;
	   
       var txtSecondNumberValue = document.getElementById('ep').value;
	    var txtThirdNumberValue = document.getElementById('price').value;
		
       if (txtFirstNumberValue == "")
           txtFirstNumberValue = 0;
       if (txtSecondNumberValue == "")
           txtSecondNumberValue = 0;

       var result = parseInt(txtNumberValue)*(parseInt(txtFirstNumberValue) *( parseInt(txtSecondNumberValue)*(350) + parseInt(txtThirdNumberValue)));
       if (!isNaN(result)) {
           document.getElementById('tmp').value = result;
       }
   }
</script>
 
</html>
