<?php
/* Template Name: karnataka */
?>

<html>
<body>
<form action="#" method="POST">


&nbsp;
<center>
<h1 style="color:#088A85;">Select city to visit.</h1>

<table style="background-color:#088A85; border-color:white;">

<tbody>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Bengaluru" /><label>Bengaluru</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Coorg" /><label>Coorg</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Mysore" /><label>Mysore</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Udupi" /><label>Udupi</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Hampi" /><label>Hampi</label></td>
</tr>
<tr style="background-color:FFF0F5;">
<td><input name="chooseone" type="radio" value="Nagerhole" /><label>Nagerhole</label></td>
</tr>

<tr style="background-color:FFF0F5;"><td>
<label><b>Select Date</b></label>
<input name="txt2" type="date" /></td></tr></br>

<tr style="background-color:FFF0F5;"><td style="border:none;" colspan="2" align="center"><input  style="background-color:#04B4AE;" name="sub" type="submit" value="Submit" /></td></tr>


</tbody>
</table>
</center>
</form>

</body>
</html>







<?php
if(isset($_POST['sub']))
{
$dt=mysql_escape_string($_POST['txt2']);
$place=mysql_escape_string($_POST['chooseone']);

global $current_user;
      get_currentuserinfo();
$user=$current_user->user_login;

$conn = mysql_connect("localhost","root","");
mysql_select_db('training');
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
  if(!empty($dt)&&!empty($place))
{

  $query="select * from tripdetails where dt='$dt' and place='$place'";
  $result=mysql_query($query,$conn) or die(mysql_error());
   
   while($row = mysql_fetch_array($result)){
   $r=$row['place'];
   $s=$row['dt'];
   }
  
  if($r!=($place) && $s!=($dt))
  {
  
   $sql = "INSERT INTO tripdetails(user_name,place,dt)VALUES('$user','$place','$dt')";
  
   
   $retval = mysql_query( $sql, $conn );
   
 
   if(! $retval ) {
      die('Could not enter data: ' . mysql_error());
	 
   }
   
   

   
   
   
   
   
if (isset($_POST['sub'])) {
if(isset($_POST['chooseone'])&& !empty($dt))
{
echo $current_user->user_login;
echo " selected ".$_POST['chooseone']."\n"; 
echo "on \n" .$dt; //  Displaying Selected Value
}

}
}

else{
   echo "<h3><center>someone else has already booked to your destination on $dt</center></h3>";
   
   }


}

else
{
echo "<h3><center>Enter trip details properly</center></h3>";
}

}
?>




