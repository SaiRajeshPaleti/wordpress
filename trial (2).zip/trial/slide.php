
<!--
<div class="slideshow-container">
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img class="alignnone size-full wp-image-186" src="http://localhost:8012/wordpress/wp-content/uploads/2017/03/4.jpg" alt="" width="199" height="253" />
    <div class="text">Caption Text</div>
  </div>
  
  <div class="slideshow-container">
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img class="alignnone size-full wp-image-186" src="http://localhost:8012/wordpress/wp-content/uploads/2017/03/3.jpg" alt="" width="199" height="253" />
    <div class="text">Caption Text</div>
  </div>
  
  
  <div class="slideshow-container">
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img class="alignnone size-full wp-image-186" src="http://localhost:8012/wordpress/wp-content/uploads/2017/03/1.jpg" alt="" width="199" height="253" />
    <div class="text">Caption Text</div>
  </div>


<div class="slideshow-container">
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img class="alignnone size-full wp-image-186" src="http://localhost:8012/wordpress/wp-content/uploads/2017/03/2.jpg" alt="" width="199" height="253" />
    <div class="text">Caption Text</div>
  </div>
  
  
  <div class="slideshow-container">
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img class="alignnone size-full wp-image-186" src="http://localhost:8012/wordpress/wp-content/uploads/2017/03/sample.png" alt="" width="199" height="253" />
    <div class="text">Caption Text</div>
  </div>
  
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
  
  

  

<script language="javascript">

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1} 
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block"; 
  dots[slideIndex-1].className += " active";
}
</script>
-->




<?php
/**
 * Get the posts by a category
 */
$my_posts = get_posts(array('cat' => 2));
/**
 * Initiate the output
 */
$output = '';
/** Loop through the post */
foreach($my_posts as $post) {
    /** Add Thumbnail to the anchor if present
     * Else The post title
     */
    $output .= '<li><a href="' . get_permalink($post->ID) . '">';
    if(has_post_thumbnail($post->ID))
        $output .= get_the_post_thumbnail($post->ID);
    else
        $output .= $post->post_title;
    /**
     * Close the widget
     */
    $output .= '</a></li>';
}
echo $output;
?> 
<!--https://www.intechgrity.com/getting-post-thumbnail-on-wordpress-3-w-wo-specific-post-id/ -->





























