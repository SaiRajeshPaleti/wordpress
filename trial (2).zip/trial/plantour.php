<?php
/* Template Name: plantour */

?>
<?php session_start();

global $r,$s,$t,$row,$row1,$package,$place,$result,$tourp;
$dt=$_SESSION['date'];

$place=$_SESSION['plac'];


$user=$_SESSION['user'];

global $selectres,$selectRes;
global $line;

mysql_connect("localhost","root","");
mysql_select_db("training");

 ?>
<html>
<body>
<form action="#" method="POST" target="_parent">
<center>
<h2 style="color:#088A85;">Select Tour Package.</h2>
<table style="background-color:#088A85; border-color:white;">
<tbody>
<tr>
<td colspan='2'><?php  $query ="SELECT package FROM tourpackages where city='$place'";
 $result = mysql_query($query); 


?>


      <select  name="tourpackage">
	   <option> <?php echo "SELECT";?>

  </option> 
      <?php while ($line = mysql_fetch_array($result)){ ?> 


	  
      <option value="<?php echo $line['package'];?>"> <?php echo $line['package'];?>

  </option>   <?php } ?> </select></td>
</tr></br>
<tr><td ><label style="color:white;">Number of Adults </label></td><td><input type="text" name="adults" /></td></tr></br>
<tr><td> <label style="color:white;">Number of Children </label></td><td><input type="text" name="child" /></td></tr></br>

<tr><td style="border:none;" colspan="2" align="center"><input  style="background-color:white;" name="sub" type="submit" value="Submit" /></td></tr>
</table>
</center>
</body>
</html>


<?php

 
if(isset($_POST['sub']))
{



if(!empty($place)&&!empty($dt))
{

$conn = mysql_connect("localhost","root","");
mysql_select_db('training');
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
   
   $package=$_POST['tourpackage'];
$adult=$_POST['adults'];
$child=$_POST['child'];
$_SESSION['tp']=$package;
echo $_SESSION['tp'];

  $query="select * from tripdetails where dt='$dt' and place='$place' and tourpackage='$package'";
  $result=mysql_query($query,$conn) or die(mysql_error());
   
   while($row = mysql_fetch_array($result)){
   $r=$row['place'];
   $s=$row['dt'];
   $t=$row['tourpackage'];
   }
  
  if($r!=($place) && $s!=($dt) && $t!=($package))
  {
  
   $sql = "INSERT INTO tripdetails(user_name,place,dt,tourpackage,Number_of_adults,Number_of_children)VALUES('$user','$place','$dt','$package','$adult','$child')";
  
   
   $retval = mysql_query( $sql, $conn );
   
 
   if(! $retval ) {
      die('Could not enter data: ' . mysql_error());
	 
   }
   
   

   
   
   
   
   
if (isset($_POST['sub'])) {
if(isset($_POST['tourpackage'])){
$selectSQL = "SELECT user_name,place,dt,tourpackage,Number_of_adults,Number_of_children FROM `tripdetails` WHERE `user_name`='$user' and `place`='$place' and `dt`='$dt' and `tourpackage`='$package'";
$selectsql="SELECT package_duration,adult_fare,child_fare,adult_food,child_food FROM `tourpackages` WHERE `package`='$package' and `city`='$place'";
$selectres = mysql_query($selectsql);

  
  if( !( $selectRes = mysql_query( $selectSQL ) )){
    echo 'Retrieval of data from Database Failed - #'.mysql_errno().': '.mysql_error();
	
	
  }else{
  
 
  
  ?>
  </br></br>
 <div class="table">   
<table border="1" style="background-color:E6E6FA; border-color:white;">
  <thead>
    <tr style="background-color:FFF0F5;">
      <th>Name</th>
      <th>Place</th>
      <th>Date</th>
      <th>Tour Package</th>
	  <th>Package Duration</th>
	  <th>Number Of Adults</th>
	  <th>Number Of Children</th>
	  <th>Adult Travel Fare Per Head</th>
	  <th>Child Travel Fare Per Head</th>
	  <th>Adult Food Fare Per Head</th>
	  <th>Child Food Fare Per Head</th>
	  
	  
    </tr>
  </thead>
  <tbody>
  
  
  
  
  
  
    <?php
	
	
      if( (mysql_num_rows( $selectRes )==0)){
        echo '<tr><td colspan="4">No Rows Returned</td></tr>';
      }else{
       while( ($row = mysql_fetch_assoc( $selectRes ))&& ($row1 = mysql_fetch_assoc( $selectres ) )){
		
          echo "<tr><td>{$row['user_name']}</td><td>{$row['place']}</td><td>{$row['dt']}</td><td>{$row['tourpackage']}</td><td>{$row1['package_duration']}</td><td>{$row['Number_of_adults']}</td><td>{$row['Number_of_children']}</td>
	  <td>{$row1['adult_fare']}</td><td>{$row1['child_fare']}</td><td>{$row1['adult_food']}</td><td>{$row1['child_food']}</td></tr>\n";
      }
		
		$result1=$row1['adult_fare']+$row1['adult_food'];
		$result2=$row1['child_fare']+$row1['child_food'];/*+($row['Number_of_children']*(($row1['child_fare'])+($row1['child_food'])));*/
		
	
	 	$result=($adult*$result1)+($child*$result2);
		/*while(( )){
		
		echo "<tr><td>{$row1['package_duration']}</td><td>{$row1['adult_fare']}</td><td>{$row1['child_fare']}</td><td>{$row1['adult_food']}</td><td>{$row1['child_food']}</td></tr>";

		}*/
		
      }
	  
    ?>
  </tbody>
</table>
</div></br></br>
<form action="#" method="POST">
<center>
<table style="background-color:#088A85; border-color:white;"><tr><td>
<label style="color:white;">Total Bill</label></td><td><input type="text" style="padding-left:20px;" name="bill" required="true" value="<?php echo $result;?>" readonly="true">
</br></td></tr><tr><td>
<label style="color:white;">
For Conformation please enter your mobile number</label></td><td><input type="text"  name="mob"/></td></tr></br></br>
<tr><td colspan="2" ><center><input style="background-color:white;" type="submit" value= "conform booking" name="conform" /></center></td></tr></table></center>
</form>
<?php
}

}
}

else{
   echo "<h3><center>someone else has already booked to your destination on</center></h3>";
   echo $dt;
   }


}

else
{
echo "<h3><centre>Enter trip details properly</centre></h3>";
}
}
}
?>

<?php
if(isset($_POST['conform']))
{
$total=$_POST['bill'];
$mob=$_POST['mob'];

$tourp=$_SESSION['tp'];

mysql_connect("localhost","root","");
mysql_select_db("training");
$update="UPDATE tripdetails
SET bill = '$total', contact_number= '$mob'
WHERE user_name='$user' AND place='$place' AND dt='$dt' AND tourpackage='$tourp'";
$modify = mysql_query( $update) or die(mysql_error()) ;
echo "<script type='text/javascript'>alert('Your Tour has been Confirmed...Visit Again..');window.location.href = 'welcome'</script>";
}
?>